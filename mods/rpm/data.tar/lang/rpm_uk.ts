<!DOCTYPE TS><TS>
<context>
    <name>AddSrcdlg</name>
    <message>
        <source>Add Wizard new source</source>
        <translation>Майстер додавання нового джерела</translation>
    </message>
    <message>
        <source>&lt;b&gt;First step&lt;/b&gt;</source>
        <translation>&lt;b&gt;Перший крок&lt;/b&gt;</translation>
    </message>
    <message>
        <source>Name source:</source>
        <translation>Ім&apos;я джерела:</translation>
    </message>
    <message>
        <source>&amp;CD/DVD</source>
        <translation>&amp;CD/DVD</translation>
    </message>
    <message>
        <source>...</source>
        <translation>...</translation>
    </message>
    <message>
        <source>Source path:</source>
        <translation>Шлях до джерела:</translation>
    </message>
    <message>
        <source>&lt;b&gt;Added source&lt;/b&gt;</source>
        <translation>&lt;b&gt;Додавання джерела&lt;/b&gt;</translation>
    </message>
</context>
<context>
    <name>Add_Rem_dlg</name>
    <message>
        <source>Install options</source>
        <translation>Опції інсталяції</translation>
    </message>
    <message>
        <source>Install all (recommended)</source>
        <translation>Встановити все (рекомендовано)</translation>
    </message>
    <message>
        <source>Install only selected</source>
        <translation>Встановити лише вибрані</translation>
    </message>
    <message>
        <source>Install</source>
        <translation>Встановити</translation>
    </message>
    <message>
        <source>Remove options</source>
        <translation>Опції видалення</translation>
    </message>
    <message>
        <source>Remove All (recommended)</source>
        <translation>Видалити все (рекомендовано)</translation>
    </message>
    <message>
        <source>Remove &amp;only selected</source>
        <translation>Видалити &amp;тільки вибрані</translation>
    </message>
    <message>
        <source>Remove</source>
        <translation>Видалити</translation>
    </message>
    <message>
        <source>Finish</source>
        <translation>Завершити</translation>
    </message>
    <message>
        <source>Report</source>
        <translation>Звіт</translation>
    </message>
    <message>
        <source>Process</source>
        <translation>Процес</translation>
    </message>
    <message>
        <source>Status</source>
        <translation>Статус</translation>
    </message>
    <message>
        <source>error</source>
        <translation>помилка</translation>
    </message>
    <message>
        <source>Causes</source>
        <translation>Причина</translation>
    </message>
    <message>
        <source>succes</source>
        <translation>завершено</translation>
    </message>
    <message>
        <source>Abort install</source>
        <translation>Преривання інсталяції</translation>
    </message>
    <message>
        <source>You already want to abort install process?</source>
        <translation>Ви дійсно хочете прервати процес інсталяції?</translation>
    </message>
    <message>
        <source>Abort remove</source>
        <translation>Переривання видалення</translation>
    </message>
    <message>
        <source>You already want to abort remove process?</source>
        <translation>Ви дійсно хочете перервати процес видалення?</translation>
    </message>
    <message>
        <source>&amp;Yes</source>
        <translation>&amp;Так</translation>
    </message>
    <message>
        <source>&amp;No</source>
        <translation>&amp;Ні</translation>
    </message>
    <message>
        <source>Preparing</source>
        <translation>Підготовка</translation>
    </message>
    <message>
        <source>&lt;h3&gt;Install packages&lt;/h3&gt;Program automatically checked dependences of the packages chosen by you and will add those which were not chosen by you, however, which are needed for satisfaction of dependences of the packages chosen by you. Packages are chosen by you will be in a section the &lt;b&gt;Selected&lt;/b&gt; is added the program in a section &lt;b&gt;Additional&lt;/b&gt;.&lt;br&gt;&lt;b&gt;Remark&lt;/b&gt;. The program conducts a search only in the indicated sources (a section is a manager of sources). In case if the program will add packages, a section will appear the Additional packages, two variants will be offered to you:&lt;ul&gt;&lt;li&gt;Install all  packages - will be install indicated in sections chosen and additional.&lt;/li&gt;&lt;li&gt;Install only selected packages - which are indicated in a section Selected will be install, in this case can be negativnand consequences (and can be not): some programs can be not loaded, or work incorrectly, in the case of delete the choice of this option can lead to collapse of the operating system.&lt;/li&gt;&lt;/ul&gt;</source>
        <translation type="obsolete">&lt;h3&gt;Інсталяція пакунків&lt;/h3&gt;Програма автоматично провірить залежності вибраних вами пакунків і додасть ті, які не були вибрані вами, однак, які необхідні для задоволення залежностей вибраних вами пакунків. Пакети вибрані вами будуть знаходитись у розділі Вибрані, додані програмою в розділі Додаткові. 
Зауваження. Програма проводить пошук лише у вказаних джерелах (розділ менеджер джерел).
У випадку, якщо програма додасть пакунки, появиться розділ Додаткові пакунки, вам буде запропоновано два варіанти:&lt;ul&gt;
&lt;li&gt;встановити всі – будуть встановлені пакунки вказані у розділах вибрані і додаткові.&lt;/li&gt;
&lt;li&gt;встановити лише вибрані – будуть встановлені пакунки, які вказані в розділі Вибрані, в даному випадку можуть бути негативні наслідки (а можуть і не бути): деякі програми можуть не завантажуватись, або працювати невірно.&lt;/li&gt;&lt;/ul&gt;</translation>
    </message>
    <message>
        <source>&lt;h3&gt;Remove packages&lt;/h3&gt;Program automatically checked dependences of the packages chosen by you and will add those which were not chosen by you, however, which are needed for satisfaction of dependences of the packages chosen by you. Packages are chosen by you will be in a section the &lt;b&gt;Selected&lt;/b&gt; is added the program in a section &lt;b&gt;Additional&lt;/b&gt;.&lt;br&gt;&lt;b&gt;Remark&lt;/b&gt;. The program conducts a search only in the indicated sources (a section is a manager of sources). In case if the program will add packages, a section will appear the Additional packages, two variants will be offered to you:&lt;ul&gt;&lt;li&gt;Remove all  packages - will be remove indicated in sections chosen and additional.&lt;/li&gt;&lt;li&gt;Remove only chosen packages - which are indicated in a section Selected will be remove, in this case can be negativnand consequences (and can be not): some programs can be not loaded, or work incorrectly, in the case of delete the choice of this option can lead to collapse of the operating system.&lt;/li&gt;&lt;/ul&gt;</source>
        <translation type="obsolete">&lt;h3&gt;Видалення пакунків&lt;/h3&gt;Програма автоматично провірить залежності вибраних вами пакунків і додасть ті, які не були вибрані вами, однак, які необхідні для задоволення залежностей вибраних вами пакунків. Пакети вибрані вами будуть знаходитись у розділі Вибрані додані програмою в розділі Додаткові. 
Зауваження. Програма проводить пошук лише у вказаних джерелах (розділ менеджер джерел).
У випадку, якщо програма додасть пакунки, появиться розділ Додаткові пакунки, вам буде запропоновано два варіанти:&lt;ul&gt;
&lt;li&gt;видалити всі – будуть видалені пакунки вказані у розділах вибрані і додаткові.&lt;/li&gt;
&lt;li&gt;видалити лише вибрані – будуть видалені пакунки, які вказані в розділі Вибрані, в даному випадку можуть бути негативні наслідки (а можуть і не бути): деякі програми можуть не завантажуватись, або працювати невірно, також вибір цієї опції може призвести до краху операційної системи.&lt;/li&gt;&lt;/ul&gt;</translation>
    </message>
    <message>
        <source>Installation</source>
        <translation>Інсталяція</translation>
    </message>
    <message>
        <source>Deleting</source>
        <translation>Видалення</translation>
    </message>
    <message>
        <source>&lt;h3&gt;Install packages&lt;/h3&gt;Program automatically checked dependences of the packages chosen by you and will add those which were not chosen by you, however, which are needed for satisfaction of dependences of the packages chosen by you. Packages are chosen by you will be in a section the &lt;b&gt;Selected&lt;/b&gt; is added the program in a section &lt;b&gt;Additional&lt;/b&gt;.&lt;br&gt;&lt;b&gt;Remark&lt;/b&gt;. The program conducts a search only in the indicated sources (see help section manager sources). In case if the program will add packages, a section will appear the Additional packages, two variants will be offered to you:&lt;ul&gt;&lt;li&gt;Install all  packages - will be install indicated in sections chosen and additional.&lt;/li&gt;&lt;li&gt;Install only selected packages - which are indicated in a section Selected will be install, in this case can be negativnand consequences (and can be not): some programs can be not loaded, or work incorrectly, in the case of delete the choice of this option can lead to collapse of the operating system.&lt;/li&gt;&lt;/ul&gt;</source>
        <translation>&lt;h3&gt;Інсталяція пакунків&lt;/h3&gt;Програма автоматично провірить залежності вибраних вами пакунків і додасть ті, які не були вибрані вами, однак, які необхідні для задоволення залежностей вибраних вами пакунків. Пакети вибрані вами будуть знаходитись у розділі Вибрані, додані програмою в розділі Додаткові. 
Зауваження. Програма проводить пошук лише у вказаних джерелах (див розділ довідки менеджер джерел).
У випадку, якщо програма додасть пакунки, появиться розділ Додаткові пакунки, вам буде запропоновано два варіанти:&lt;ul&gt;
&lt;li&gt;встановити всі – будуть встановлені пакунки вказані у розділах вибрані і додаткові.&lt;/li&gt;
&lt;li&gt;встановити лише вибрані – будуть встановлені пакунки, які вказані в розділі Вибрані, в даному випадку можуть бути негативні наслідки (а можуть і не бути): деякі програми можуть не завантажуватись, або працювати невірно.&lt;/li&gt;&lt;/ul&gt;</translation>
    </message>
    <message>
        <source>&lt;h3&gt;Remove packages&lt;/h3&gt;Program automatically checked dependences of the packages chosen by you and will add those which were not chosen by you, however, which are needed for satisfaction of dependences of the packages chosen by you. Packages are chosen by you will be in a section the &lt;b&gt;Selected&lt;/b&gt; is added the program in a section &lt;b&gt;Additional&lt;/b&gt;.&lt;br&gt;&lt;b&gt;Remark&lt;/b&gt;. The program conducts a search only in the indicated sources (see help section manager sources). In case if the program will add packages, a section will appear the Additional packages, two variants will be offered to you:&lt;ul&gt;&lt;li&gt;Remove all  packages - will be remove indicated in sections chosen and additional.&lt;/li&gt;&lt;li&gt;Remove only chosen packages - which are indicated in a section Selected will be remove, in this case can be negativnand consequences (and can be not): some programs can be not loaded, or work incorrectly, in the case of delete the choice of this option can lead to collapse of the operating system.&lt;/li&gt;&lt;/ul&gt;</source>
        <translation>&lt;h3&gt;Видалення пакунків&lt;/h3&gt;Програма автоматично провірить залежності вибраних вами пакунків і додасть ті, які не були вибрані вами, однак, які необхідні для задоволення залежностей вибраних вами пакунків. Пакети вибрані вами будуть знаходитись у розділі Вибрані додані програмою в розділі Додаткові. 
Зауваження. Програма проводить пошук лише у вказаних джерелах (див розділ довідки менеджер джерел).
У випадку, якщо програма додасть пакунки, появиться розділ Додаткові пакунки, вам буде запропоновано два варіанти:&lt;ul&gt;
&lt;li&gt;видалити всі – будуть видалені пакунки вказані у розділах вибрані і додаткові.&lt;/li&gt;
&lt;li&gt;видалити лише вибрані – будуть видалені пакунки, які вказані в розділі Вибрані, в даному випадку можуть бути негативні наслідки (а можуть і не бути): деякі програми можуть не завантажуватись, або працювати невірно, також вибір цієї опції може призвести до краху операційної системи.&lt;/li&gt;&lt;/ul&gt;</translation>
    </message>
</context>
<context>
    <name>EditSource</name>
    <message>
        <source>Source manager</source>
        <translation>Менеджер джерел</translation>
    </message>
    <message>
        <source>Source Name</source>
        <translation>Ім&apos;я джерела</translation>
    </message>
    <message>
        <source>Path</source>
        <translation>Шлях</translation>
    </message>
    <message>
        <source>CD/DVD</source>
        <translation></translation>
    </message>
    <message>
        <source>Remo&amp;ve</source>
        <translation type="obsolete">Видалення</translation>
    </message>
    <message>
        <source>Remove selected source</source>
        <translation>Видалити вибране джерело</translation>
    </message>
    <message>
        <source>A&amp;dd ...</source>
        <translation type="obsolete">Додати</translation>
    </message>
    <message>
        <source>Added new source</source>
        <translation>Додавання нового джерела</translation>
    </message>
    <message>
        <source>Edi&amp;t ...</source>
        <translation type="obsolete">Редагувати</translation>
    </message>
    <message>
        <source>Edit select source</source>
        <translation>Редагування вибраного джерела</translation>
    </message>
    <message>
        <source>Update</source>
        <translation>Поновити</translation>
    </message>
    <message>
        <source>Update selected Source</source>
        <translation>Поновити вибране джерело</translation>
    </message>
    <message>
        <source>Save</source>
        <translation>Зберегти</translation>
    </message>
    <message>
        <source>Discard</source>
        <translation>Відкинути</translation>
    </message>
    <message>
        <source>Remove</source>
        <translation>Видалити</translation>
    </message>
    <message>
        <source>Add ...</source>
        <translation>Додати ...</translation>
    </message>
    <message>
        <source>Edit ...</source>
        <translation>Редагувати ...</translation>
    </message>
    <message>
        <source>on/off</source>
        <translation>Вікн/Вимкн</translation>
    </message>
    <message>
        <source>Status</source>
        <translation>Статус</translation>
    </message>
</context>
<context>
    <name>Left_Panel</name>
    <message>
        <source>Form1</source>
        <translation></translation>
    </message>
</context>
<context>
    <name>QInfoPanel</name>
    <message>
        <source>Package</source>
        <translation>Пакунок</translation>
    </message>
    <message>
        <source>Detailed</source>
        <translation>Деталі</translation>
    </message>
    <message>
        <source>Version</source>
        <translation>Версія</translation>
    </message>
    <message>
        <source>Size</source>
        <translation>Розмір</translation>
    </message>
    <message>
        <source>Architecture</source>
        <translation>Архітектура</translation>
    </message>
    <message>
        <source>Source</source>
        <translation>Джерело</translation>
    </message>
    <message>
        <source>Description</source>
        <translation>Опис</translation>
    </message>
    <message>
        <source>Information only available for installed packages</source>
        <translation>Інформація доступна лише для встановлених пакунків</translation>
    </message>
    <message>
        <source>Files</source>
        <translation>Файли</translation>
    </message>
    <message>
        <source>files</source>
        <translation>файли</translation>
    </message>
    <message>
        <source>Provide names</source>
        <translation>Надає</translation>
    </message>
    <message>
        <source>provides</source>
        <translation>надає</translation>
    </message>
    <message>
        <source>Empty</source>
        <translation>Порожньо</translation>
    </message>
</context>
<context>
    <name>RPM_Views</name>
    <message>
        <source>Groups rpm</source>
        <translation>Групи rpm</translation>
    </message>
    <message>
        <source>Name</source>
        <translation>Ім&apos;я</translation>
    </message>
    <message>
        <source>Description</source>
        <translation>Опис</translation>
    </message>
    <message>
        <source>Version</source>
        <translation>Версія</translation>
    </message>
    <message>
        <source>Platform</source>
        <translation>Платформа</translation>
    </message>
    <message>
        <source>Preparing install ...</source>
        <translation>Підготовка інсталяції...</translation>
    </message>
    <message>
        <source>Ready</source>
        <translation>Готово</translation>
    </message>
    <message>
        <source>Preparing remove ...</source>
        <translation>Підготовка видалення...</translation>
    </message>
    <message>
        <source>Building tree group packages ...</source>
        <translation>Побудова дерева груп пакунків...</translation>
    </message>
    <message>
        <source>Please wait. Building group tree RPM ....</source>
        <translation>Будь-ласка зачекайте. Побудова дерева груп RPM...</translation>
    </message>
    <message>
        <source>z All</source>
        <translation>яя Всі</translation>
    </message>
    <message>
        <source>Not found</source>
        <translation>Не знайдено</translation>
    </message>
    <message>
        <source>Please wait. Get records RPM .... read: %1 reacords in %2</source>
        <translation>Будь-ласка зачекайте. Витягування записів RPM .... прочитано: %1 записів із %2</translation>
    </message>
    <message>
        <source>Empty</source>
        <translation>Порожньо</translation>
    </message>
    <message>
        <source>No packages to install. Please select Rpm/Edit sources to add rpm source.</source>
        <translation>Не знайдено пакунків зля встановлення. Виберіть Rpm/Edit sources щоб дати джерело пакунків.</translation>
    </message>
</context>
<context>
    <name>SCT_Left_Panel</name>
    <message>
        <source>Packages statistic</source>
        <translation>Статистика пакунків</translation>
    </message>
    <message>
        <source>Selected</source>
        <translation>Вибрані</translation>
    </message>
    <message>
        <source>Size</source>
        <translation>Розмір</translation>
    </message>
    <message>
        <source>Disk&apos;s statistic</source>
        <translation>Статистика розділів</translation>
    </message>
    <message>
        <source>Device</source>
        <translation>Пристрій</translation>
    </message>
    <message>
        <source>Available</source>
        <translation>Доступно</translation>
    </message>
    <message>
        <source>Mounted to</source>
        <translation>Монтовано до</translation>
    </message>
</context>
<context>
    <name>addSrcImpl</name>
    <message>
        <source>Select Directory</source>
        <translation>Виберіть директорію</translation>
    </message>
    <message>
        <source>Info</source>
        <translation>Інформація</translation>
    </message>
    <message>
        <source>Please enter name Media</source>
        <translation>Будь-ласка введіть ім&apos;я джерела</translation>
    </message>
    <message>
        <source>Please enter path to Media</source>
        <translation>Будь-ласка введіть шлях до джерела</translation>
    </message>
    <message>
        <source>Preparing added ... </source>
        <translation>Підготування додавання ...</translation>
    </message>
    <message>
        <source>Abort</source>
        <translation>Прервати</translation>
    </message>
    <message>
        <source>Completed</source>
        <translation>Завершено</translation>
    </message>
    <message>
        <source>Added</source>
        <translation>Додавання</translation>
    </message>
    <message>
        <source>Job is success completed.</source>
        <translation>роботу успішно завершено.</translation>
    </message>
    <message>
        <source>Added %1 among %2</source>
        <translation>Додано %1 із %2</translation>
    </message>
    <message>
        <source>package</source>
        <translation>пакунок</translation>
    </message>
    <message>
        <source>Error added</source>
        <translation>Помилка додавання</translation>
    </message>
    <message>
        <source>package : Error read header</source>
        <translation>пакунок: помилка читання заголовку</translation>
    </message>
    <message>
        <source>package : Can&apos;t read package</source>
        <translation>пакунок: неможу прочитати пакунок</translation>
    </message>
    <message>
        <source>&lt;h3&gt;Add and source wizard.&lt;/h3&gt;Enter the name of source (choose on own discretion), the option of &lt;b&gt;CD/DVD&lt;/b&gt; specifies on te that this source is  CD/DVD by a disk. In the field to the source specify a path where bales are. Push button &lt;b&gt;next&lt;/b&gt;, to begin the process of addition.</source>
        <translation type="obsolete">&lt;h3&gt;Add and source wizard.&lt;/h3&gt;Enter the name of source (choose on own discretion), the option of &lt;b&gt;CD/DVD&lt;/b&gt; specifies on te that this source is(sp)(sp)CD/DVD by a disk. In the field to the source specify a path where bales are. Push button &lt;b&gt;next&lt;/b&gt;, to begin the process of addition.</translation>
    </message>
    <message>
        <source>&lt;h3&gt;Add and edit source wizard.&lt;/h3&gt;Enter the name of source (choose on own discretion), the option of &lt;b&gt;CD/DVD&lt;/b&gt; specifies on te that this source is  CD/DVD by a disk. In the field to the source specify a path where bales are. Push button &lt;b&gt;next&lt;/b&gt;, to begin the process of addition.</source>
        <translation type="obsolete">&lt;h3&gt; Майстер додавання і редагування джерела.&lt;/h3&gt;Введіть назву джерела (вибираєте на власний розсуд), опція &lt;b&gt;CD/DVD&lt;/b&gt; вказує на те що дане джерело є  CD/DVD диском. В полі шлях до джерела вказуєте де знаходяться пакунки. Натискаєте кнопку &lt;b&gt;Далі&lt;/b&gt; щоб почати процес додавання.</translation>
    </message>
    <message>
        <source>&lt;h3&gt;Add and edit source wizard.&lt;/h3&gt;Enter the name of source (choose on own discretion), the option of &lt;b&gt;CD/DVD&lt;/b&gt; specifies on te that this source is  CD/DVD by a disk. In the field to the source specify a path where packages are. Push button &lt;b&gt;next&lt;/b&gt;, to begin the process of addition.</source>
        <translation>&lt;h3&gt; Майстер додавання і редагування джерела.&lt;/h3&gt;Введіть назву джерела (вибираєте на власний розсуд), опція &lt;b&gt;CD/DVD&lt;/b&gt; вказує на те що дане джерело є  CD/DVD диском. В полі шлях до джерела вказуєте де знаходяться пакунки. Натискаєте кнопку &lt;b&gt;Далі&lt;/b&gt; щоб почати процес додавання.</translation>
    </message>
</context>
<context>
    <name>findDlg</name>
    <message>
        <source>Find</source>
        <translation>Шукати</translation>
    </message>
    <message>
        <source>&lt;font size=&quot;+1&quot;&gt;&lt;u&gt;Find&lt;/u&gt;&lt;/font&gt;</source>
        <translation>&lt;font size=&quot;+1&quot;&gt;&lt;u&gt;Пошук&lt;/u&gt;&lt;/font&gt;</translation>
    </message>
    <message>
        <source>Find in</source>
        <translation>Шукати в</translation>
    </message>
    <message>
        <source>name</source>
        <translation>назвах</translation>
    </message>
    <message>
        <source>&amp;description</source>
        <translation type="obsolete">&amp;описах</translation>
    </message>
    <message>
        <source>summar&amp;y</source>
        <translation type="obsolete">підсумку</translation>
    </message>
    <message>
        <source>That find</source>
        <translation>Що шукати</translation>
    </message>
    <message>
        <source>wat&apos;s find</source>
        <translation>що шукати</translation>
    </message>
    <message>
        <source>&lt;i&gt;Select wat&apos;s find file or package &lt;/i&gt;</source>
        <translation>&lt;i&gt;Виберіть що шукати пакунок чи файл &lt;/i&gt;</translation>
    </message>
    <message>
        <source>File</source>
        <translation>Файл</translation>
    </message>
    <message>
        <source>compare no case</source>
        <translation>чутливість до регістру</translation>
    </message>
    <message>
        <source>description</source>
        <translation>Опис</translation>
    </message>
    <message>
        <source>summary</source>
        <translation>підсумок</translation>
    </message>
    <message>
        <source>Package</source>
        <translation>Пакунок</translation>
    </message>
    <message>
        <source>absolutely coincide</source>
        <translation>абсолютне співпадання</translation>
    </message>
</context>
<context>
    <name>info_panel</name>
    <message>
        <source>Info</source>
        <translation>Інформація</translation>
    </message>
    <message>
        <source>Description</source>
        <translation>Опис</translation>
    </message>
    <message>
        <source>Contents</source>
        <translation>Вміст</translation>
    </message>
    <message>
        <source>Change Log</source>
        <translation>Системний журнал</translation>
    </message>
    <message>
        <source>Depends</source>
        <translation>Залежності</translation>
    </message>
</context>
<context>
    <name>rpm_dlg</name>
    <message>
        <source>rpm</source>
        <translation></translation>
    </message>
    <message>
        <source>Count</source>
        <translation>Кількість</translation>
    </message>
    <message>
        <source>item</source>
        <translation></translation>
    </message>
    <message>
        <source>select options</source>
        <translation>опції вибору</translation>
    </message>
    <message>
        <source>selected</source>
        <translation>вибрані</translation>
    </message>
    <message>
        <source>all</source>
        <translation>всі</translation>
    </message>
    <message>
        <source>Install/Remove</source>
        <translation></translation>
    </message>
    <message>
        <source>Cnacel</source>
        <translation>Відмова</translation>
    </message>
    <message>
        <source>Log</source>
        <translation>Лог</translation>
    </message>
    <message>
        <source>Advertisement</source>
        <translation>реклама</translation>
    </message>
    <message>
        <source>&lt;center&gt;&lt;font color=&quot;#3388ff&quot; size=&quot;+2&quot;&gt;Here maybe your advertisement :-)&lt;/font&gt;&lt;/center&gt;</source>
        <translation>&lt;center&gt;&lt;font color=&quot;#3388ff&quot; size=&quot;+2&quot;&gt;Тут могла б бути ваша реклама :-)&lt;/font&gt;&lt;/center&gt;</translation>
    </message>
</context>
<context>
    <name>rpm_manager</name>
    <message>
        <source>ERROR:could not read database record
</source>
        <translation>ПОМИЛКА: неможу прочитати запис бази даних</translation>
    </message>
    <message>
        <source>not found</source>
        <translation>не знайдено</translation>
    </message>
    <message>
        <source>Preparing process ...</source>
        <translation>Підготовка процесу...</translation>
    </message>
    <message>
        <source>Selected packages</source>
        <translation>Вибрані пакунки</translation>
    </message>
    <message>
        <source>Package</source>
        <translation>Пакунок</translation>
    </message>
    <message>
        <source>Deppends</source>
        <translation>Залежності</translation>
    </message>
    <message>
        <source>Additional packages</source>
        <translation>Додаткові пакунки</translation>
    </message>
    <message>
        <source>Find package in source... </source>
        <translation>Пошук пакунка в джерелі...</translation>
    </message>
    <message>
        <source>ok</source>
        <translation></translation>
    </message>
    <message>
        <source>Unleash deppends ...</source>
        <translation>Розв&apos;язання залежностей ...</translation>
    </message>
    <message>
        <source>Item</source>
        <translation>елемент</translation>
    </message>
    <message>
        <source>Status</source>
        <translation>Статус</translation>
    </message>
    <message>
        <source>Find package in data base... </source>
        <translation>Пошук пакунка в базі даних ...</translation>
    </message>
    <message>
        <source>Unleash deppends</source>
        <translation>Розв&apos;язання залежностей</translation>
    </message>
    <message>
        <source>Please wait. This take one or several minutes.</source>
        <translation>Будь-ласка зачекайте. Це може зайняти одну або декілька хвилин. </translation>
    </message>
    <message>
        <source>User cancled</source>
        <translation>Відмінено користувачем</translation>
    </message>
    <message>
        <source>Please insert source:</source>
        <translation>Будьласка вставте джерело:</translation>
    </message>
    <message>
        <source>Insert source</source>
        <translation>Вставка джерела</translation>
    </message>
    <message>
        <source>&amp;OK</source>
        <translation>&amp;OK</translation>
    </message>
    <message>
        <source>&amp;Cancel</source>
        <translation>&amp;Cancel</translation>
    </message>
    <message>
        <source>Installation</source>
        <translation>Інсталяція</translation>
    </message>
    <message>
        <source>Can&apos;t find mount command. Please mount media is manually.</source>
        <translation>Не можу знайти команду mount. Буть-ласка змонтуйте пристрій вручну.</translation>
    </message>
    <message>
        <source>Installing</source>
        <translation>Інсталяція</translation>
    </message>
    <message>
        <source>Succes</source>
        <translation>Завершено</translation>
    </message>
    <message>
        <source>Remove</source>
        <translation>Видалення</translation>
    </message>
    <message>
        <source>Error package</source>
        <translation>Помилка пакунка</translation>
    </message>
    <message>
        <source>User canceled</source>
        <translation>Відмінено користувачем</translation>
    </message>
    <message>
        <source>succes</source>
        <translation>завершено</translation>
    </message>
    <message>
        <source>rpm message</source>
        <translation>Повідомлення rpm</translation>
    </message>
    <message>
        <source>Rpm out message</source>
        <translation></translation>
    </message>
    <message>
        <source>continue ?</source>
        <translation>продовжити?</translation>
    </message>
    <message>
        <source>Yes</source>
        <translation>Так</translation>
    </message>
    <message>
        <source>No</source>
        <translation>Ні</translation>
    </message>
</context>
<context>
    <name>rpm_ui</name>
    <message>
        <source>Error</source>
        <translation>помилка</translation>
    </message>
    <message>
        <source>Can&apos;t load icons.</source>
        <translation>Неможу завантажити іконки.</translation>
    </message>
    <message>
        <source>Information</source>
        <translation>Інформація</translation>
    </message>
    <message>
        <source>You execute package manager like not root. If you want
 install, remove packages or edit sources, please run like root.</source>
        <translation type="obsolete">Ви запустили програму не як root. Якщо ви хочете встановлювати, видаляти пакунки,
редагувати джерела завантажте програму від імені користувача root.</translation>
    </message>
    <message>
        <source>Info</source>
        <translation>Інформація</translation>
    </message>
    <message>
        <source>Can&apos;t find help files</source>
        <translation type="obsolete">не можу знайти файли довідки</translation>
    </message>
    <message>
        <source>Rpm</source>
        <translation></translation>
    </message>
    <message>
        <source>View</source>
        <translation>Вигляд</translation>
    </message>
    <message>
        <source>Help</source>
        <translation>Довідка</translation>
    </message>
    <message>
        <source>View installed packages</source>
        <translation>Перегляд встановлених пакунків</translation>
    </message>
    <message>
        <source>Installed packages</source>
        <translation>Встановлені пакунки</translation>
    </message>
    <message>
        <source>View not installed packages</source>
        <translation>Перегляд невстановлених пакунків</translation>
    </message>
    <message>
        <source>Not installed packages</source>
        <translation>Невстановлені пакунки</translation>
    </message>
    <message>
        <source>Reload database rpm</source>
        <translation>Перевандажити базу rpm</translation>
    </message>
    <message>
        <source>Reload</source>
        <translation>Перевантажити</translation>
    </message>
    <message>
        <source>Install</source>
        <translation>Встановити</translation>
    </message>
    <message>
        <source>Find</source>
        <translation>Пошук</translation>
    </message>
    <message>
        <source>Find package or file</source>
        <translation>Пошук пакунка або файлу</translation>
    </message>
    <message>
        <source>Edit sources</source>
        <translation>Редагувати джерела</translation>
    </message>
    <message>
        <source>Exit</source>
        <translation>Вихід</translation>
    </message>
    <message>
        <source>Index...</source>
        <translation>Індекс...</translation>
    </message>
    <message>
        <source>About</source>
        <translation>Про</translation>
    </message>
    <message>
        <source>Rpm remove operations</source>
        <translation>Rpm операції видалення</translation>
    </message>
    <message>
        <source>Remove packages</source>
        <translation>Видалити пакунки</translation>
    </message>
    <message>
        <source>Remove</source>
        <translation>Видалити</translation>
    </message>
    <message>
        <source>Edit source</source>
        <translation>Редагувати джерело</translation>
    </message>
    <message>
        <source>Edit sources packages</source>
        <translation>Редагувати джерела пакунків</translation>
    </message>
    <message>
        <source>Remove selected packages</source>
        <translation>Видалити вибрані пакунки</translation>
    </message>
    <message>
        <source>Rpm install operations</source>
        <translation>Rpm операції встановлення</translation>
    </message>
    <message>
        <source>Install packages</source>
        <translation>Встановити пакунки</translation>
    </message>
    <message>
        <source>Install selected packages</source>
        <translation>Встановити вибрані пакунки</translation>
    </message>
    <message>
        <source>About SCT rpm BETA1</source>
        <translation>Про SCT rpm BETA1</translation>
    </message>
    <message>
        <source>RPM package manager BETA1.
Module for SCT.
development: pkdev@i.ua</source>
        <translation type="obsolete">RPM менеджер пакунків BETA1.
Модуль для SCT.
розробка: pkdev@i.ua</translation>
    </message>
    <message>
        <source>RPM package manager BETA1.
Module for SCT.
development: sksoft@i.ua</source>
        <translation>RPM менеджер пакунків BETA1.
Модуль для SCT.
Розробка: sksoft@i.ua</translation>
    </message>
    <message>
        <source>Can&apos;t find help system.</source>
        <translation>Не можу знайти систему перегліду довідки.</translation>
    </message>
    <message>
        <source>You execute package manager like not root.
 If you want install, remove packages or edit sources, please run like root.</source>
        <translation>Ви запустили програму не як root.
Якщо ви хочете встановлювати, видаляти пакунки, редагувати джерела завантажте програму від імені користувача root.</translation>
    </message>
</context>
<context>
    <name>selectsourceImpl</name>
    <message>
        <source>Remove source - SCT rpm</source>
        <translation>Видалити джерело - SCT rpm</translation>
    </message>
    <message>
        <source>You already want remove &lt;b&gt;%1&lt;/b&gt; source.</source>
        <translation>Ви дійсно хочете видалити джерело &lt;b&gt;%1&lt;/b&gt;.</translation>
    </message>
    <message>
        <source>Yes</source>
        <translation>Так</translation>
    </message>
    <message>
        <source>No</source>
        <translation>Ні</translation>
    </message>
    <message>
        <source>No source</source>
        <translation>Не джерело</translation>
    </message>
    <message>
        <source>Not found source. Please insert source.</source>
        <translation>Не знайдено джерело. Будь-ласка вставте джерело.</translation>
    </message>
    <message>
        <source>Abort</source>
        <translation>Прервати</translation>
    </message>
    <message>
        <source>Can&apos;t read file.</source>
        <translation>Не можу прочитати файл.</translation>
    </message>
    <message>
        <source>User canceled.</source>
        <translation>Перевано користувачем.</translation>
    </message>
    <message>
        <source>Not found</source>
        <translation>Не знайдено</translation>
    </message>
    <message>
        <source>This path is not exists. Please set correct path to source.</source>
        <translation>Цей шлях не існує. Будь-ласка введіть правильний шлях.</translation>
    </message>
    <message>
        <source>&lt;h3&gt;Source manager.&lt;/h3&gt;Here you can execute various operations with sources. A source is this place (folder, cd, dvd) where rpm bales are. Accessible next operations of addition, delete, editing, renewal.&lt;br&gt;&lt;b&gt;Add&lt;/b&gt; - is addition of new source.&lt;br&gt;&lt;b&gt;Delete&lt;/b&gt; - is a delete of existent source.&lt;br&gt;&lt;b&gt;Editing&lt;/b&gt; - is a change of the name of existent source, or to the path where it is.&lt;br&gt;Renewal  if you to the source (for example, to the directory ) added new bales or deleted about it it is needed to report manager of sources, choosing a necessary source and pushing the button to renew. To save information about added, remote or press the renewed sources to &lt;b&gt;save&lt;/b&gt; the button, if no - &lt;b&gt;discard&lt;/b&gt;.</source>
        <translation type="obsolete">&lt;h3&gt;Менеджер джерел.&lt;/h3&gt;Тут ви можете виконувати різноманітні операції із джерелами. Джерело це місце (тека, cd, dvd) де знаходяться rpm пакунки. Доступні наступні операції додавання, видалення, редагування, поновлення.
&lt;b&gt;Додавання&lt;/b&gt; – додавання нового джерела.
&lt;b&gt;Видалення&lt;/b&gt; – видалення існуючого джерела.
&lt;b&gt;Редагування&lt;/b&gt; – зміна назви існуючого джерела, або шляху де воно знаходиться.
&lt;b&gt;Поновлення&lt;/b&gt; – якщо ви до джерела (наприклад, каталогу ) додали нові пакунки або видалили то про це потрібно повідомити менеджер джерел, вибравши потрібне джерело і натиснувши кнопку поновити.
Щоб зберегти інформацію про додані, видалені чи поновлені джерела натисніть кнопку &lt;b&gt;зберегти&lt;/b&gt;, якщо ж ні - &lt;b&gt;відкинути&lt;/b&gt;.</translation>
    </message>
    <message>
        <source>&lt;h3&gt;Source manager.&lt;/h3&gt;Here you can execute various operations with sources. A source is this place (folder, cd, dvd) where rpm packages are. Accessible next operations of addition, delete, editing, renewal.&lt;br&gt;&lt;b&gt;Add&lt;/b&gt; - is addition of new source.&lt;br&gt;&lt;b&gt;Delete&lt;/b&gt; - is a delete of existent source.&lt;br&gt;&lt;b&gt;Editing&lt;/b&gt; - is a change of the name of existent source, or to the path where it is.&lt;br&gt;&lt;b&gt;Update&lt;b&gt; - if you to the source (for example, to the directory ) added new packages or deleted about it it is needed to report manager of sources, choosing a necessary source and pushing the button to renew. To save information about added, remote or press the renewed sources to &lt;b&gt;save&lt;/b&gt; the button, if no - &lt;b&gt;discard&lt;/b&gt;.</source>
        <translation type="obsolete">&lt;h3&gt;Менеджер джерел.&lt;/h3&gt;Тут ви можете виконувати різноманітні операції із джерелами. Джерело це місце (тека, cd, dvd) де знаходяться rpm пакунки. Доступні наступні операції додавання, видалення, редагування, поновлення.
&lt;b&gt;Додавання&lt;/b&gt; – додавання нового джерела.
&lt;b&gt;Видалення&lt;/b&gt; – видалення існуючого джерела.
&lt;b&gt;Редагування&lt;/b&gt; – зміна назви існуючого джерела, або шляху де воно знаходиться.
&lt;b&gt;Поновлення&lt;/b&gt; – якщо ви до джерела (наприклад, каталогу ) додали нові пакунки або видалили то про це потрібно повідомити менеджер джерел, вибравши потрібне джерело і натиснувши кнопку поновити.
Щоб зберегти інформацію про додані, видалені чи поновлені джерела натисніть кнопку &lt;b&gt;зберегти&lt;/b&gt;, якщо ж ні - &lt;b&gt;відкинути&lt;/b&gt;.</translation>
    </message>
    <message>
        <source>&lt;h3&gt;Source manager.&lt;/h3&gt;Here you can execute various operations with sources. A source is this place (folder, cd, dvd) where rpm packages are. Accessible next operations of addition, delete, editing, renewal.&lt;br&gt;&lt;b&gt;Add&lt;/b&gt; - is addition of new source.&lt;br&gt;&lt;b&gt;Delete&lt;/b&gt; - is a delete of existent source.&lt;br&gt;&lt;b&gt;Editing&lt;/b&gt; - is a change of the name of existent source, or to the path where it is.&lt;br&gt;&lt;b&gt;Update&lt;/b&gt; - if you to the source (for example, to the directory ) added new packages or deleted about it it is needed to report manager of sources, choosing a necessary source and pushing the button to renew. To save information about added, remote or press the renewed sources to &lt;b&gt;save&lt;/b&gt; the button, if no - &lt;b&gt;discard&lt;/b&gt;.</source>
        <translation>&lt;h3&gt;Менеджер джерел.&lt;/h3&gt;Тут ви можете виконувати різноманітні операції із джерелами. Джерело це місце (тека, cd, dvd) де знаходяться rpm пакунки. Доступні наступні операції додавання, видалення, редагування, поновлення.
&lt;b&gt;Додавання&lt;/b&gt; – додавання нового джерела.
&lt;b&gt;Видалення&lt;/b&gt; – видалення існуючого джерела.
&lt;b&gt;Редагування&lt;/b&gt; – зміна назви існуючого джерела, або шляху де воно знаходиться.
&lt;b&gt;Поновлення&lt;/b&gt; – якщо ви до джерела (наприклад, каталогу ) додали нові пакунки або видалили то про це потрібно повідомити менеджер джерел, вибравши потрібне джерело і натиснувши кнопку поновити.
Щоб зберегти інформацію про додані, видалені чи поновлені джерела натисніть кнопку &lt;b&gt;зберегти&lt;/b&gt;, якщо ж ні - &lt;b&gt;відкинути&lt;/b&gt;.</translation>
    </message>
    <message>
        <source>YES</source>
        <translation>ТАК</translation>
    </message>
    <message>
        <source>ON</source>
        <translation>Вімкн</translation>
    </message>
    <message>
        <source>NO</source>
        <translation>НІ</translation>
    </message>
    <message>
        <source>OFF</source>
        <translation>Вимкн</translation>
    </message>
</context>
</TS>
