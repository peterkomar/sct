<!DOCTYPE TS><TS>
<context>
    <name>QObject</name>
    <message>
        <source>Hard Disk</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>mount</source>
        <translation>монтувати</translation>
    </message>
    <message>
        <source>Mount partitions</source>
        <translation>Монтування розділів</translation>
    </message>
</context>
<context>
    <name>SelectMode</name>
    <message>
        <source>Unmount parameter</source>
        <translation>Параметри розмонтування</translation>
    </message>
    <message>
        <source>Close</source>
        <translation>Закрити</translation>
    </message>
    <message>
        <source>Finish</source>
        <translation>Завершити</translation>
    </message>
    <message>
        <source>Force</source>
        <translation>Примусово</translation>
    </message>
    <message>
        <source>Force unmount</source>
        <translation>Примусово розмонтувати</translation>
    </message>
    <message>
        <source>Force unmount.</source>
        <translation>Примусово розмонтувати.</translation>
    </message>
</context>
<context>
    <name>editMount</name>
    <message>
        <source>Close</source>
        <translation>Закрити</translation>
    </message>
    <message>
        <source>Finish</source>
        <translation>Завершити</translation>
    </message>
    <message>
        <source>Information</source>
        <translation>Інформація</translation>
    </message>
    <message>
        <source>Size :</source>
        <translation>Розмір:</translation>
    </message>
    <message>
        <source>Type :</source>
        <translation>Тип :</translation>
    </message>
    <message>
        <source>Partition :</source>
        <translation>Розділ :</translation>
    </message>
    <message>
        <source>3</source>
        <translation></translation>
    </message>
    <message>
        <source>2</source>
        <translation></translation>
    </message>
    <message>
        <source>1</source>
        <translation></translation>
    </message>
    <message>
        <source>Mount</source>
        <translation>Монтувати</translation>
    </message>
    <message>
        <source>Mount Point</source>
        <translation>Точка ионтування</translation>
    </message>
    <message>
        <source>Type FS</source>
        <translation>Тип ФС</translation>
    </message>
    <message>
        <source>/mnt/C</source>
        <translation></translation>
    </message>
    <message>
        <source>/mnt/D</source>
        <translation></translation>
    </message>
    <message>
        <source>/mnt/F</source>
        <translation></translation>
    </message>
    <message>
        <source>/mnt/E</source>
        <translation></translation>
    </message>
    <message>
        <source>/mnt/G</source>
        <translation></translation>
    </message>
    <message>
        <source>/mnt/Linux1</source>
        <translation></translation>
    </message>
    <message>
        <source>/mnt/Linux2</source>
        <translation></translation>
    </message>
    <message>
        <source>Mount point</source>
        <translation>Точка монтування</translation>
    </message>
    <message>
        <source>vfat</source>
        <translation></translation>
    </message>
    <message>
        <source>ext3</source>
        <translation></translation>
    </message>
    <message>
        <source>ext2</source>
        <translation></translation>
    </message>
    <message>
        <source>swap</source>
        <translation></translation>
    </message>
    <message>
        <source>ntfs</source>
        <translation></translation>
    </message>
    <message>
        <source>reiserfs</source>
        <translation></translation>
    </message>
    <message>
        <source>auto</source>
        <translation></translation>
    </message>
    <message>
        <source>type file systen (vfat, ext3, auto,...)</source>
        <translation>Тип файлової системи (vfat, ext3, auto,...)</translation>
    </message>
    <message>
        <source>Mount parameter</source>
        <translation>Параметри монтування</translation>
    </message>
    <message>
        <source>noatime</source>
        <translation></translation>
    </message>
    <message>
        <source>ro</source>
        <translation></translation>
    </message>
    <message>
        <source>iocharset =</source>
        <translation></translation>
    </message>
    <message>
        <source>codepage</source>
        <translation></translation>
    </message>
    <message>
        <source>sync</source>
        <translation></translation>
    </message>
    <message>
        <source>Arbitrary options value:</source>
        <translation>Вибіркові опції:</translation>
    </message>
    <message>
        <source>Enter other parameter </source>
        <translation>Ввести інші пареметри</translation>
    </message>
    <message>
        <source>umask=0002</source>
        <translation></translation>
    </message>
    <message>
        <source>noexec</source>
        <translation></translation>
    </message>
    <message>
        <source>users</source>
        <translation></translation>
    </message>
    <message>
        <source>nodev</source>
        <translation></translation>
    </message>
    <message>
        <source>nosuid</source>
        <translation></translation>
    </message>
    <message>
        <source>koi8-u</source>
        <translation></translation>
    </message>
    <message>
        <source>koi8-r</source>
        <translation></translation>
    </message>
    <message>
        <source>utf8</source>
        <translation></translation>
    </message>
    <message>
        <source>char set in partition (koi8-u, utf8, ...)</source>
        <translation>Кодування в розділі (koi8-u, utf8, ...) </translation>
    </message>
    <message>
        <source>&lt;i&gt;All operations i/o filesystem must be run synchronously</source>
        <translation>&lt;i&gt;Усі операції вводу-виводу файлової системи повинні виконуватись синхронізовано</translation>
    </message>
    <message>
        <source>&lt;i&gt;Do  not  update  inode  access  times on this file system
(e.g, for faster access on the news  spool  to  speed  up
news servers)&lt;/i&gt;</source>
        <translation>&lt;i&gt;Не поновлювати час доступу у файловій системі. (Необхідно для сереврів новин)</translation>
    </message>
    <message>
        <source>866</source>
        <translation></translation>
    </message>
    <message>
        <source>&lt;i&gt;(Other mount parameter ex.( gid=users,utf8=true,noauto)&lt;/i&gt;</source>
        <translation>&lt;i&gt;Інші параметри пр. ( gid=users,utf8=true,noauto)&lt;/i&gt;</translation>
    </message>
    <message>
        <source>&lt;i&gt;Do not allow set-user-identifier or  set-group-identifier
bits  to  take  effect.  (This seems safe, but is in fact
rather unsafe if you have suidperl(1) installed.)&lt;/i&gt;</source>
        <translation>&lt;i&gt;Не дозволяти встановлювати біти set-user-identifier або set-group-identifier </translation>
    </message>
    <message>
        <source>&lt;i&gt;Enable write for users&lt;/i&gt;</source>
        <translation>Дозволити запис користувачам</translation>
    </message>
    <message>
        <source>&lt;i&gt;Enable users mount and unmount this partition&lt;/i&gt;</source>
        <translation>&lt;i&gt;Дозволити монтувати і розмонтовувати цей розділ&lt;/i&gt;</translation>
    </message>
    <message>
        <source>&lt;i&gt;Disable run binary files in mounted partition&lt;/i&gt;</source>
        <translation>&lt;i&gt;Заборонити виконання бінарних файлів у цьому розділі&lt;/i&gt;</translation>
    </message>
    <message>
        <source>&lt;i&gt;Do  not  interpret character or block special devices on
the file system.&lt;/i&gt;</source>
        <translation>&lt;i&gt;Не інтерпритувати символ або блокувати спеціальні символи у файловій системі</translation>
    </message>
    <message>
        <source>&lt;i&gt;Mount the file system read-only&lt;/i&gt;</source>
        <translation>&lt;i&gt;Монтувати в режимі тільки читати&lt;/i&gt;</translation>
    </message>
    <message>
        <source>Mount Parameter</source>
        <translation>Параметри монтування</translation>
    </message>
</context>
<context>
    <name>mount_ui</name>
    <message>
        <source>Partition</source>
        <translation>Розділ</translation>
    </message>
    <message>
        <source>Size</source>
        <translation>Розмір</translation>
    </message>
    <message>
        <source>Type</source>
        <translation>Тип</translation>
    </message>
    <message>
        <source>Mount Point</source>
        <translation>Точка монтування</translation>
    </message>
    <message>
        <source>Mount Parameters</source>
        <translation>Параметри монтування</translation>
    </message>
    <message>
        <source>Name in DOS</source>
        <translation>Ім&apos;я в ДОС</translation>
    </message>
    <message>
        <source>Mounted</source>
        <translation>Монтований</translation>
    </message>
    <message>
        <source>Root</source>
        <translation></translation>
    </message>
    <message>
        <source>Mount</source>
        <translation>Монтувати</translation>
    </message>
    <message>
        <source>Unmount</source>
        <translation>Розмонтувати</translation>
    </message>
    <message>
        <source>mount partition</source>
        <translation>Монтувати розділ</translation>
    </message>
    <message>
        <source>mount</source>
        <translation>монтувати</translation>
    </message>
    <message>
        <source>unmount partition</source>
        <translation>Розмонтувати розділ</translation>
    </message>
    <message>
        <source>unmount</source>
        <translation>розмонтувати</translation>
    </message>
    <message>
        <source>Mount Menu</source>
        <translation>Меню монтування</translation>
    </message>
    <message>
        <source>Mounted to : %1</source>
        <translation>Монтований до : %1 </translation>
    </message>
    <message>
        <source>Error unmount</source>
        <translation>Помилка монтування</translation>
    </message>
    <message>
        <source>You don&apos;t unmount root partition.&apos;</source>
        <translation>Ви не можете розмонтувати кореневий розділ.&apos;</translation>
    </message>
    <message>
        <source>Info</source>
        <translation>Інформація</translation>
    </message>
    <message>
        <source>Can&apos;t find help files</source>
        <translation type="obsolete">Не можу знайти файли довідки</translation>
    </message>
    <message>
        <source>Data</source>
        <translation>Дані</translation>
    </message>
    <message>
        <source>View</source>
        <translation>Вид</translation>
    </message>
    <message>
        <source>Help</source>
        <translation>Довідка</translation>
    </message>
    <message>
        <source>Mode write data to fstab file</source>
        <translation>Режим запису до fstab файлу</translation>
    </message>
    <message>
        <source>Write to fstab file</source>
        <translation>Запис до fstab</translation>
    </message>
    <message>
        <source>Exit</source>
        <translation>Вихід</translation>
    </message>
    <message>
        <source>Expert mode</source>
        <translation>Режим Експерт</translation>
    </message>
    <message>
        <source>Expert</source>
        <translation>Експерт</translation>
    </message>
    <message>
        <source>Index...</source>
        <translation>Індекс...</translation>
    </message>
    <message>
        <source>About</source>
        <translation>Про</translation>
    </message>
    <message>
        <source>%1:(%2)
Size:%3
Type:%4
Path:%5</source>
        <translation>%1:(%2)
Розмір:%3
Тип:%4
Шлях:%5</translation>
    </message>
    <message>
        <source>%1:(%2)
Size:%3
Type:%4
Path:&lt;not mounted&gt;</source>
        <translation>%1:(%2)
Розмір:%3
Тип:%4
Шлях:&lt;не монтовано&gt;</translation>
    </message>
    <message>
        <source>Scan</source>
        <translation>Сканувати</translation>
    </message>
    <message>
        <source>&lt;h3&gt;Ordinary mode.&lt;/h3&gt;&lt;b&gt;Attention.&lt;/b&gt;That sections were automatically connected with the parameters presetby you at the load of the system it is necessary to set mode of recordin the file of fstab &lt;b&gt;Data/Write to fstab&lt;/b&gt;. Before setting this mode information about editing of sections in the file of /etc/fstab is not written down. (It is recommended to create the back-up copy of file of /etc/fstab).&lt;br&gt;&lt;br&gt;To mount a section it is necessary to choose him and push the button to &lt;b&gt;Mount&lt;/b&gt;, or avail context dependent menus and the program automatically will define parameters and will connect the chosen section and will show information where the set section was connected. Like carried out unmount of section instruction &lt;b&gt;Unmount&lt;/b&gt; execution. If you need greater control above editing of section commuted in the mode of expert &lt;b&gt;View/Expert&lt;/b&gt;. The button is intended to &lt;b&gt;Scan&lt;/b&gt; for the exposure of new sections which were connected to the computer already after the start of the program. (Example: USB flash disk and others like that).</source>
        <translation type="obsolete">&lt;h3&gt;Звичайний режим.&lt;/h3&gt;
&lt;b&gt;Увага&lt;/b&gt;. Для того щоб розділи автоматично підключались із заданими вами параметрами при завантаженні системи необхідно включити режим запису у файл fstab &lt;b&gt;Дані/Запис в fstab&lt;/b&gt;. До включення цього режиму інформація про монтування розділів у файл /etc/fstab не записується. (Рекомендується створити резервну копію файлу /etc/fstab).

Щоб змонтувати розділ необхідно вибрати його і натиснути кнопку &lt;b&gt;Монтувати&lt;/b&gt;, або скористатись контекстно залежним меню і програма автоматично визначить параметри і підключить вибраний розділ і покаже інформацію куди було підключено заданий розділ. Аналогічно здійснюється розмонтування розділу виконанням команди &lt;b&gt;Розмонтувати&lt;/b&gt;. Якщо вам потрібний більший контроль над монтуванням розділу переключіться в режим експерта &lt;b&gt;Вид/Експерт&lt;/b&gt;. 
Кнопка Сканувати призначена для виявлення нових розділів, які були підключені до комп’ютера уже після запуску програми. (Приклад: USB флеш диск тощо).</translation>
    </message>
    <message>
        <source>&lt;h3&gt;Mode of expert.&lt;/h3&gt;Attention. That sections were automatically connected with the parameters presetby you at the load of the system it is necessary to set mode of record in the file of fstab&lt;b&gt;Data/Write to fstab&lt;/b&gt;. Before setting this mode information about editing of sections in the file of/etc/fstab is not written down. (It is recommended to create the back-up copy of file of /etc/fstab).&lt;br&gt;&lt;br&gt;In the mode of expert you will be able in hand to set the parameters of editing. This mode befits moreskilled users which know naming of hard disks in &lt;b&gt;Linux&lt;/b&gt; systems and they know theparameters of connecting of sections. For those users which the parameters of editing areunknown accessible system of prompts it is enough to point the cursor of mouse in the windowof editing on a parameter which interests you. Mounting, unmount, scanning is conducted liketill it is done in the ordinary mode.</source>
        <translation type="obsolete">&lt;h3&gt;Режим експерта.&lt;/h3&gt;
&lt;b&gt;Увага&lt;/b&gt;. Для того щоб розділи автоматично підключались із заданими вами параметрами при завантаженні системи необхідно включити режим запису у файл fstab &lt;b&gt;Дані/Запис в fstab&lt;/b&gt;. До включення цього режиму інформація про монтування розділів у файл /etc/fstab не записується. (Рекомендується створити резервну копію файлу /etc/fstab).

В режимі експерта ви зможете в ручну задавати параметри монтування. Цей режим підходить більш досвідченим користувачам яким відомо іменування жорстких дисків у Linux системах і їм відомі параметри підключення розділів. Для тих користувачів яким невідомі параметри монтування доступна система підказок достатньо навести курсор мишки у вікні монтування на параметр який вас цікавить. Монтування, розмонтування, сканування проводиться аналогічно до того як це робиться в звичайному режимі.</translation>
    </message>
    <message>
        <source>About SCT mount</source>
        <translation>Про SCT mount</translation>
    </message>
    <message>
        <source>&lt;h3&gt;Mode of expert.&lt;/h3&gt;Attention. That sections were automatically connected with the parameters presetby you at the load of the system it is necessary to set mode of record in the file of fstab &lt;b&gt;Data/Write to fstab&lt;/b&gt;. Before setting this mode information about editing of sections in the file of/etc/fstab is not written down. (It is recommended to create the back-up copy of file of /etc/fstab).&lt;br&gt;&lt;br&gt;In the mode of expert you will be able in hand to set the parameters of editing. This mode befits moreskilled users which know naming of hard disks in &lt;b&gt;Linux&lt;/b&gt; systems and they know theparameters of connecting of sections. For those users which the parameters of editing areunknown accessible system of prompts it is enough to point the cursor of mouse in the windowof editing on a parameter which interests you. Mounting, unmount, scanning is conducted liketill it is done in the ordinary mode.</source>
        <translation type="obsolete">&lt;h3&gt;Режим експерта.&lt;/h3&gt;
&lt;b&gt;Увага&lt;/b&gt;. Для того щоб розділи автоматично підключались із заданими вами параметрами при завантаженні системи необхідно включити режим запису у файл fstab &lt;b&gt;Дані/Запис в fstab&lt;/b&gt;. До включення цього режиму інформація про монтування розділів у файл /etc/fstab не записується. (Рекомендується створити резервну копію файлу /etc/fstab).

В режимі експерта ви зможете в ручну задавати параметри монтування. Цей режим підходить більш досвідченим користувачам яким відомо іменування жорстких дисків у Linux системах і їм відомі параметри підключення розділів. Для тих користувачів яким невідомі параметри монтування доступна система підказок достатньо навести курсор мишки у вікні монтування на параметр який вас цікавить. Монтування, розмонтування, сканування проводиться аналогічно до того як це робиться в звичайному режимі.</translation>
    </message>
    <message>
        <source>&lt;h3&gt;Ordinary mode.&lt;/h3&gt;&lt;b&gt;Attention.&lt;/b&gt;That sections were automatically connected with the parameters preset by you at the load of the system it is necessary to set mode of record in the file of fstab &lt;b&gt;Data/Write to fstab&lt;/b&gt;. Before setting this mode information about editing of sections in the file of /etc/fstab is not written down. (It is recommended to create the back-up copy of file of /etc/fstab).&lt;br&gt;&lt;br&gt;To mount a section it is necessary to choose him and push the button to &lt;b&gt;Mount&lt;/b&gt;, or avail context dependent menus and the program automatically will define parameters and will connect the chosen section and will show information where the set section was connected. Like carried out unmount of section instruction &lt;b&gt;Unmount&lt;/b&gt; execution. If you need greater control above editing of section commuted in the mode of expert &lt;b&gt;View/Expert&lt;/b&gt;. The button is intended to &lt;b&gt;Scan&lt;/b&gt; for the exposure of new sections which were connected to the computer already after the start of the program. (Example: USB flash disk and others like that).</source>
        <translation>&lt;h3&gt;Звичайний режим.&lt;/h3&gt;
&lt;b&gt;Увага&lt;/b&gt;. Для того щоб розділи автоматично підключались із заданими вами параметрами при завантаженні системи необхідно включити режим запису у файл fstab &lt;b&gt;Дані/Запис в fstab&lt;/b&gt;. До включення цього режиму інформація про монтування розділів у файл /etc/fstab не записується. (Рекомендується створити резервну копію файлу /etc/fstab).

Щоб змонтувати розділ необхідно вибрати його і натиснути кнопку &lt;b&gt;Монтувати&lt;/b&gt;, або скористатись контекстно залежним меню і програма автоматично визначить параметри і підключить вибраний розділ і покаже інформацію куди було підключено заданий розділ. Аналогічно здійснюється розмонтування розділу виконанням команди &lt;b&gt;Розмонтувати&lt;/b&gt;. Якщо вам потрібний більший контроль над монтуванням розділу переключіться в режим експерта &lt;b&gt;Вид/Експерт&lt;/b&gt;. 
Кнопка Сканувати призначена для виявлення нових розділів, які були підключені до комп’ютера уже після запуску програми. (Приклад: USB флеш диск тощо).</translation>
    </message>
    <message>
        <source>&lt;h3&gt;Mode of expert.&lt;/h3&gt;Attention. That sections were automatically connected with the parameters preset by you at the load of the system it is necessary to set mode of record in the file of fstab &lt;b&gt;Data/Write to fstab&lt;/b&gt;. Before setting this mode information about editing of sections in the file of /etc/fstab is not written down. (It is recommended to create the back-up copy of file of /etc/fstab).&lt;br&gt;&lt;br&gt;In the mode of expert you will be able in hand to set the parameters of editing. This mode befits more skilled users which know naming of hard disks in &lt;b&gt;Linux&lt;/b&gt; systems and they know the parameters of connecting of sections. For those users which the parameters of editing are unknown accessible system of prompts it is enough to point the cursor of mouse in the window of editing on a parameter which interests you. Mounting, unmount, scanning is conducted like till it is done in the ordinary mode.</source>
        <translation>&lt;h3&gt;Режим експерта.&lt;/h3&gt;
&lt;b&gt;Увага&lt;/b&gt;. Для того щоб розділи автоматично підключались із заданими вами параметрами при завантаженні системи необхідно включити режим запису у файл fstab &lt;b&gt;Дані/Запис в fstab&lt;/b&gt;. До включення цього режиму інформація про монтування розділів у файл /etc/fstab не записується. (Рекомендується створити резервну копію файлу /etc/fstab).

В режимі експерта ви зможете в ручну задавати параметри монтування. Цей режим підходить більш досвідченим користувачам яким відомо іменування жорстких дисків у Linux системах і їм відомі параметри підключення розділів. Для тих користувачів яким невідомі параметри монтування доступна система підказок достатньо навести курсор мишки у вікні монтування на параметр який вас цікавить. Монтування, розмонтування, сканування проводиться аналогічно до того як це робиться в звичайному режимі.</translation>
    </message>
    <message>
        <source>GUI for &lt;mount&gt; command.
Module for SCT.
development: sksoft@i.ua</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Can&apos;t find help system.</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>myMountManager</name>
    <message>
        <source>Can&apos;t open fstab file</source>
        <translation>Не можу відкрити файл fstab</translation>
    </message>
    <message>
        <source>Can&apos;t write to fstab file</source>
        <translation>Не можу записати у файл fstab</translation>
    </message>
    <message>
        <source>can&apos;t start mount command</source>
        <translation>Не можу стартувати команду mount</translation>
    </message>
    <message>
        <source>Error mount</source>
        <translation>Помилка монтування</translation>
    </message>
    <message>
        <source>can&apos;t start umount command</source>
        <translation>Не можу стартувати umount команду</translation>
    </message>
    <message>
        <source>Error umount</source>
        <translation>Помилка розмонтування</translation>
    </message>
    <message>
        <source>Can&apos;t find mtab file </source>
        <translation>Не можу знайти mtab файл</translation>
    </message>
    <message>
        <source>Error</source>
        <translation>Помилка</translation>
    </message>
    <message>
        <source>Can&apos;t find &lt;mtab&gt; file.</source>
        <translation>Не можу знайти &lt;mtab&gt; файл.</translation>
    </message>
</context>
</TS>
