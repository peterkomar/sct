<!DOCTYPE TS><TS>
<context>
    <name>About</name>
    <message>
        <source>About myConfig</source>
        <translation type="obsolete">Про myConfig</translation>
    </message>
    <message>
        <source>Close</source>
        <translation>Закрити</translation>
    </message>
    <message>
        <source>&lt;font color=&quot;#4c94ff&quot;&gt;my&lt;/font&gt;&lt;font color=&quot;#d6d13c&quot;&gt;Config&lt;/font&gt; v0.7.1 using Qt 3</source>
        <translation type="obsolete">&lt;font color=&quot;#4c94ff&quot;&gt;my&lt;/font&gt;&lt;font color=&quot;#d6d13c&quot;&gt;Config&lt;/font&gt; v0.7.1 використовує Qt 3</translation>
    </message>
    <message>
        <source>A&amp;bout</source>
        <translation type="unfinished">Про</translation>
    </message>
    <message>
        <source>Small Control Center for Linux family.&lt;br&gt;&lt;br&gt;mail: &lt;font color=&quot;#61c86c&quot; size=&quot;-1&quot;&gt;pkdev@ukr.net&lt;/font&gt;&lt;br&gt;(c)2005, Peter Komar, Kurt Santes</source>
        <translation type="obsolete">Невеличкий центр керування для Linux.&lt;br&gt;&lt;br&gt;mail: &lt;font color=&quot;#61c86c&quot; size=&quot;-1&quot;&gt;pkdev@ukr.net&lt;/font&gt;&lt;br&gt;(c)2005, Peter Komar, Kurt Santes</translation>
    </message>
    <message>
        <source>&amp;Autors</source>
        <translation type="unfinished">Автори</translation>
    </message>
    <message>
        <source>Lice&amp;nse</source>
        <translation type="unfinished">Ліцензія</translation>
    </message>
    <message>
        <source>About SCT Control Center</source>
        <translation>Про SCT центр керування</translation>
    </message>
    <message>
        <source>Small Control Center for Linux family.&lt;br&gt;&lt;br&gt;mail: &lt;font color=&quot;#61c86c&quot; size=&quot;-1&quot;&gt;sksoft@i.ua&lt;/font&gt;</source>
        <translation>Центр керування для Лінукс.&lt;br&gt;&lt;br&gt;mail: &lt;font color=&quot;#61c86c&quot; size=&quot;-1&quot;&gt;sksoft@i.ua&lt;/font&gt;</translation>
    </message>
    <message>
        <source>&lt;font color=&quot;#4c94ff&quot;&gt;SCT&lt;/font&gt;&lt;font color=&quot;#d6d13c&quot;&gt;control center&lt;/font&gt; using Qt 3</source>
        <translation>&lt;font color=&quot;#4c94ff&quot;&gt;SCT&lt;/font&gt;&lt;font color=&quot;#d6d13c&quot;&gt;центр керування&lt;/font&gt; використовує Qt 3</translation>
    </message>
</context>
<context>
    <name>ListViews</name>
    <message>
        <source>Error</source>
        <translation type="obsolete">Помилка</translation>
    </message>
    <message>
        <source>Can&apos;t load Icons</source>
        <translation type="obsolete">Не можу завантажити іконки</translation>
    </message>
    <message>
        <source>Configure Tools</source>
        <translation type="obsolete">Засіб завантаження</translation>
    </message>
    <message>
        <source>Information</source>
        <translation type="obsolete">Інформація</translation>
    </message>
    <message>
        <source>Boot config</source>
        <translation type="obsolete">Завантажувачі</translation>
    </message>
    <message>
        <source>Hard Disk</source>
        <translation type="obsolete">Жорсткий диск</translation>
    </message>
    <message>
        <source>Devices</source>
        <translation type="obsolete">Пристрої</translation>
    </message>
    <message>
        <source>Network</source>
        <translation type="obsolete">Мережа</translation>
    </message>
    <message>
        <source>Software</source>
        <translation type="obsolete">Пакунки</translation>
    </message>
    <message>
        <source>System</source>
        <translation type="obsolete">Система</translation>
    </message>
    <message>
        <source>About</source>
        <translation type="obsolete">Про систему</translation>
    </message>
    <message>
        <source>Boot</source>
        <translation type="obsolete">Завантажувач</translation>
    </message>
    <message>
        <source>(Configure lilo boot loader)</source>
        <translation type="obsolete">Налаштовує завантажувач ліло</translation>
    </message>
    <message>
        <source>(Configure your boot loader)</source>
        <translation type="obsolete">Налаштовує ваш завантажувач</translation>
    </message>
    <message>
        <source>(Listen information of your computer)</source>
        <translation type="obsolete">Показує інформацію про ваш комп&apos;ютер</translation>
    </message>
    <message>
        <source>(Configure your display)</source>
        <translation type="obsolete">Налаштовує ваш дисплей</translation>
    </message>
    <message>
        <source>(Configure your sound cart)</source>
        <translation type="obsolete">Налаштовує вашу звукову картку</translation>
    </message>
    <message>
        <source>(Configure your keyboard)</source>
        <translation type="obsolete">Налаштовує вашу клавіатуру</translation>
    </message>
    <message>
        <source>(Configure your printer)</source>
        <translation type="obsolete">Налаштовує ваш принтер</translation>
    </message>
    <message>
        <source>(Configure your scaner)</source>
        <translation type="obsolete">Налаштовує ваш сканер</translation>
    </message>
    <message>
        <source>(Configure your mouse)</source>
        <translation type="obsolete">Налаштовує вашу мишку</translation>
    </message>
    <message>
        <source>(Mount your partitions)</source>
        <translation type="obsolete">Монтує ваші розділи</translation>
    </message>
    <message>
        <source>(Your mount manager)</source>
        <translation type="obsolete">Ваш менеджер монтування</translation>
    </message>
    <message>
        <source>(Configure your network)</source>
        <translation type="obsolete">Налаштовує вашу мережу</translation>
    </message>
    <message>
        <source>(Configure Web server)</source>
        <translation type="obsolete">Налаштовує ваш Web серевер</translation>
    </message>
    <message>
        <source>(Configure Samba server)</source>
        <translation type="obsolete">Налаштовує ваш Самба серевер</translation>
    </message>
    <message>
        <source>(Configure NFS server)</source>
        <translation type="obsolete">Налаштовує ваш NFS серевер</translation>
    </message>
    <message>
        <source>(Configure FTP server)</source>
        <translation type="obsolete">Налаштовує FTP серевер</translation>
    </message>
    <message>
        <source>(Configure Mail Server)</source>
        <translation type="obsolete">Налаштовує вашу пошту</translation>
    </message>
    <message>
        <source>(Configure DNS Server)</source>
        <translation type="obsolete">Налаштовує ваш DNS сервер</translation>
    </message>
    <message>
        <source>(Configure DHCP Server)</source>
        <translation type="obsolete">Налаштовує ваш DHCP сервер</translation>
    </message>
    <message>
        <source>(Configure Proxy Server)</source>
        <translation type="obsolete">Налаштовує ваш проксі серевер</translation>
    </message>
    <message>
        <source>(Your package manager)</source>
        <translation type="obsolete">Ваш менеджер пакунків</translation>
    </message>
    <message>
        <source>(Install or Remove Software)</source>
        <translation type="obsolete">Встановлення та видалення програм</translation>
    </message>
    <message>
        <source>(Preview and Install package or packages)</source>
        <translation type="obsolete">Перегляд і інсталяція пакунків або пакунка</translation>
    </message>
    <message>
        <source>(Configure users or groups in your computer)</source>
        <translation type="obsolete">Конфігурує користувачів та групи на вашому комп&apos;ютері</translation>
    </message>
    <message>
        <source>(Configure date and time)</source>
        <translation type="obsolete">Налаштовує дату і час</translation>
    </message>
    <message>
        <source>(Listen System Log files)</source>
        <translation type="obsolete">Перегляд файлів журналу</translation>
    </message>
    <message>
        <source>(Configure Services in your Computer)</source>
        <translation type="obsolete">Конфігурує сервіси на вашому комп&apos;ютері </translation>
    </message>
    <message>
        <source>(Change root password)</source>
        <translation type="obsolete">Міняє пароль користувача root</translation>
    </message>
    <message>
        <source>(Configure Security in your Computer)</source>
        <translation type="obsolete">Налаштовує безпеку на вашому комп&apos;ютері</translation>
    </message>
    <message>
        <source>(Select registration manager: KDM, GDM, XDM))</source>
        <translation type="obsolete">Налаштовує менеджер реєстрації: KDM, GDM, XDM</translation>
    </message>
    <message>
        <source>(Select languange in your computer))</source>
        <translation type="obsolete">Вибирає мову вашої системи</translation>
    </message>
    <message>
        <source>&lt;p align=&quot;center&quot;&gt;&lt;font color=&quot;#10cc10&quot; size=&quot;+2&quot;&gt;Configure Tool for Linux. Version 0.6 release&lt;/font&gt;&lt;br&gt;&lt;font color=&quot;#5555ff&quot; size=&quot;-1&quot; face=&quot;Arial&quot;&gt;Development and Design: PKDevelopment Soft . All righs reserved.&lt;br&gt;mail: pkdev@yandex.ru&lt;/font&gt;&lt;/p&gt;&lt;br&gt;&lt;br&gt;&lt;br&gt;&lt;br&gt;&lt;br&gt;&lt;br&gt;&lt;br&gt;</source>
        <translation type="obsolete">&lt;p align=&quot;center&quot;&gt;&lt;font color=&quot;#10cc10&quot; size=&quot;+2&quot;&gt;Засіб налантування для Лінукс. Версія 0.6 реліз&lt;/font&gt;&lt;br&gt;&lt;font color=&quot;#5555ff&quot; size=&quot;-1&quot; face=&quot;Arial&quot;&gt;Розробка і дизайн: PKDevelopment Soft . Усі права заявлено.&lt;br&gt;Пошта: pkdev@yandex.ru&lt;/font&gt;&lt;/p&gt;&lt;br&gt;&lt;br&gt;&lt;br&gt;&lt;br&gt;&lt;br&gt;&lt;br&gt;&lt;br&gt;</translation>
    </message>
    <message>
        <source>Can&apos;t load module</source>
        <translation type="obsolete">Не можу завантажити модуль</translation>
    </message>
    <message>
        <source>Can&apos;t load: myRPM</source>
        <translation type="obsolete">Не можу завантажити myRPM</translation>
    </message>
    <message>
        <source>Can&apos;t load: rpmView</source>
        <translation type="obsolete">не можу завантажити rpmView</translation>
    </message>
    <message>
        <source>Can&apos;t load: </source>
        <translation type="obsolete">Не можу завантажити</translation>
    </message>
    <message>
        <source>Linux name:</source>
        <translation type="obsolete">Назва Лінукса:</translation>
    </message>
    <message>
        <source>Kernel release</source>
        <translation type="obsolete">Час зборки ядра</translation>
    </message>
    <message>
        <source>Kernel version</source>
        <translation type="obsolete">Версія ядра</translation>
    </message>
    <message>
        <source>Total RAM</source>
        <translation type="obsolete">Загальна пам&apos;ять</translation>
    </message>
    <message>
        <source>Computer name</source>
        <translation type="obsolete">Ім&apos;я комп&apos;ютера</translation>
    </message>
    <message>
        <source>Kernel architecture</source>
        <translation type="obsolete">Архітектура ядра</translation>
    </message>
    <message>
        <source>&lt;font color=&quot;#5555ff&quot; face=&quot;Arial&quot;&gt;Computer name :&lt;/font&gt; %s&lt;br&gt;&lt;br&gt;&lt;font color=&quot;#5555ff&quot; face=&quot;Arial&quot;&gt;Kernel architecture :&lt;/font&gt; %s&lt;br&gt;&lt;font color=&quot;#5555ff&quot; face=&quot;Arial&quot;&gt;Kernel release :&lt;/font&gt; %s&lt;br&gt;&lt;font color=&quot;#5555ff&quot; face=&quot;Arial&quot;&gt;Kernel version : &lt;/font&gt;%s&lt;br&gt;&lt;br&gt;&lt;font color=&quot;#5555ff&quot; face=&quot;Arial&quot;&gt;Total RAM :&lt;/font&gt; %5.1f MB</source>
        <translation type="obsolete">&lt;font color=&quot;#5555ff&quot; face=&quot;Arial&quot;&gt;Ім&apos;я комп&apos;ютера :&lt;/font&gt; %s&lt;br&gt;&lt;br&gt;&lt;font color=&quot;#5555ff&quot; face=&quot;Arial&quot;&gt;Архітектура ядра :&lt;/font&gt; %s&lt;br&gt;&lt;font color=&quot;#5555ff&quot; face=&quot;Arial&quot;&gt;Дата зборки ядра :&lt;/font&gt; %s&lt;br&gt;&lt;font color=&quot;#5555ff&quot; face=&quot;Arial&quot;&gt;Версія ядра : &lt;/font&gt;%s&lt;br&gt;&lt;br&gt;&lt;font color=&quot;#5555ff&quot; face=&quot;Arial&quot;&gt;Загальна пам&apos;ять :&lt;/font&gt; %5.1f MB</translation>
    </message>
    <message>
        <source>&lt;font color=&quot;#5555ff&quot; face=&quot;Arial&quot;&gt;Computer name :&lt;/font&gt; %1&lt;br&gt;&lt;br&gt;</source>
        <translation type="obsolete">&lt;font color=&quot;#5555ff&quot; face=&quot;Arial&quot;&gt;Ім&apos;я комп&apos;ютера :&lt;/font&gt; %1&lt;br&gt;&lt;br&gt;</translation>
    </message>
    <message>
        <source>&lt;font color=&quot;#5555ff&quot; face=&quot;Arial&quot;&gt;Kernel architecture :&lt;/font&gt; %1&lt;br&gt;</source>
        <translation type="obsolete">&lt;font color=&quot;#5555ff&quot; face=&quot;Arial&quot;&gt;Архітектура ядра :&lt;/font&gt; %1&lt;br&gt;</translation>
    </message>
    <message>
        <source>&lt;font color=&quot;#5555ff&quot; face=&quot;Arial&quot;&gt;Kernel release :&lt;/font&gt; %1&lt;br&gt;</source>
        <translation type="obsolete">&lt;font color=&quot;#5555ff&quot; face=&quot;Arial&quot;&gt;Зборка ядра :&lt;/font&gt; %1&lt;br&gt;</translation>
    </message>
    <message>
        <source>&lt;font color=&quot;#5555ff&quot; face=&quot;Arial&quot;&gt;Kernel version : &lt;/font&gt;%1&lt;br&gt;&lt;br&gt;</source>
        <translation type="obsolete">&lt;font color=&quot;#5555ff&quot; face=&quot;Arial&quot;&gt;Версія ядра : &lt;/font&gt;%1&lt;br&gt;&lt;br&gt;</translation>
    </message>
    <message>
        <source>&lt;font color=&quot;#5555ff&quot; face=&quot;Arial&quot;&gt;Total RAM :&lt;/font&gt; %1 MB</source>
        <translation type="obsolete">&lt;font color=&quot;#5555ff&quot; face=&quot;Arial&quot;&gt;Загальна пам&apos;ять :&lt;/font&gt; %1 MB</translation>
    </message>
    <message>
        <source>Hardware</source>
        <translation type="obsolete">Залізо</translation>
    </message>
    <message>
        <source>Display</source>
        <translation type="obsolete">Екран</translation>
    </message>
    <message>
        <source>Soundcart</source>
        <translation type="obsolete">Звукова карта</translation>
    </message>
    <message>
        <source>Keyboard</source>
        <translation type="obsolete">Клавіатура</translation>
    </message>
    <message>
        <source>Printer</source>
        <translation type="obsolete">Принтер</translation>
    </message>
    <message>
        <source>Scaner</source>
        <translation type="obsolete">Сканер</translation>
    </message>
    <message>
        <source>Mouse</source>
        <translation type="obsolete">Миша</translation>
    </message>
    <message>
        <source>Mount Points</source>
        <translation type="obsolete">Розділи</translation>
    </message>
    <message>
        <source>Web Server</source>
        <translation type="obsolete">Веб сервер</translation>
    </message>
    <message>
        <source>Samba</source>
        <translation type="obsolete">Самба сервер</translation>
    </message>
    <message>
        <source>NFS</source>
        <translation type="obsolete">NFS сервер</translation>
    </message>
    <message>
        <source>FTP</source>
        <translation type="obsolete">FTP сервер</translation>
    </message>
    <message>
        <source>Mail</source>
        <translation type="obsolete">Пошта</translation>
    </message>
    <message>
        <source>DNS</source>
        <translation type="obsolete">DNS сервер</translation>
    </message>
    <message>
        <source>DHCP</source>
        <translation type="obsolete">DHCP сервер</translation>
    </message>
    <message>
        <source>Proxy</source>
        <translation type="obsolete">Проксі сервер</translation>
    </message>
    <message>
        <source>Packages</source>
        <translation type="obsolete">Пакунки</translation>
    </message>
    <message>
        <source>Users and Groups</source>
        <translation type="obsolete">Користувачі та групи</translation>
    </message>
    <message>
        <source>Date and Time</source>
        <translation type="obsolete">Дата і час</translation>
    </message>
    <message>
        <source>Sys Log</source>
        <translation type="obsolete">Системний журнал</translation>
    </message>
    <message>
        <source>Services</source>
        <translation type="obsolete">Сервіси</translation>
    </message>
    <message>
        <source>Root Password</source>
        <translation type="obsolete">Пароль root</translation>
    </message>
    <message>
        <source>Security</source>
        <translation type="obsolete">Безпека</translation>
    </message>
    <message>
        <source>Language</source>
        <translation type="obsolete">Мова системи</translation>
    </message>
</context>
<context>
    <name>QObject</name>
    <message>
        <source>Loading...</source>
        <translation type="obsolete">Завантаження...</translation>
    </message>
    <message>
        <source>myConfig control center @pkdev soft</source>
        <translation type="obsolete">myConfig центер керування @pkdev soft</translation>
    </message>
    <message>
        <source>SCT control center Beta2 @SKsoft</source>
        <translation></translation>
    </message>
    <message>
        <source>can&apos;t open file</source>
        <translation>Не можу відкрити файл</translation>
    </message>
    <message>
        <source>Not found</source>
        <translation>Не знайдено</translation>
    </message>
    <message>
        <source>Disk&apos;s statistic</source>
        <translation>Статистика дисків</translation>
    </message>
    <message>
        <source>Device</source>
        <translation>Пристрій</translation>
    </message>
    <message>
        <source>Size</source>
        <translation>Розмір</translation>
    </message>
    <message>
        <source>Available</source>
        <translation>Доступно</translation>
    </message>
    <message>
        <source>Mounted to</source>
        <translation>Монтовано до</translation>
    </message>
    <message>
        <source>Boot loaders information</source>
        <translation>Інформація про завантажувачі</translation>
    </message>
    <message>
        <source>Hardware information</source>
        <translation>Інформація про пристрої</translation>
    </message>
    <message>
        <source>Network</source>
        <translation>Мережа</translation>
    </message>
    <message>
        <source>Host name</source>
        <translation>Ім&apos;я хосту</translation>
    </message>
    <message>
        <source>Supported packages</source>
        <translation>Підримувані пакунки</translation>
    </message>
    <message>
        <source>Debian packages</source>
        <translation>Debian пакунки</translation>
    </message>
    <message>
        <source>Support</source>
        <translation>підримується</translation>
    </message>
    <message>
        <source>Not support</source>
        <translation>не підримується</translation>
    </message>
    <message>
        <source>Rpm packages</source>
        <translation>Rpm пакунки</translation>
    </message>
    <message>
        <source>System</source>
        <translation>Система</translation>
    </message>
    <message>
        <source>Operation system</source>
        <translation>Операційна система</translation>
    </message>
    <message>
        <source>Name</source>
        <translation>Ім&apos;я</translation>
    </message>
    <message>
        <source>Kernel</source>
        <translation>Ядро</translation>
    </message>
    <message>
        <source>version</source>
        <translation>Версія</translation>
    </message>
    <message>
        <source>architecture</source>
        <translation>Архітектура</translation>
    </message>
    <message>
        <source>Environments</source>
        <translation>Оточення</translation>
    </message>
</context>
<context>
    <name>configurator</name>
    <message>
        <source>Configurator</source>
        <translation>Конфігуратор</translation>
    </message>
    <message>
        <source>Aply</source>
        <translation>Встановити</translation>
    </message>
    <message>
        <source>Close</source>
        <translation>Закрити</translation>
    </message>
    <message>
        <source>&amp;Boot, Mount, Devices</source>
        <translation type="unfinished">Завантаження, Монтування, Пристрої</translation>
    </message>
    <message>
        <source>...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Path to program config xserver</source>
        <translation>Програма конфіг. xserver</translation>
    </message>
    <message>
        <source>Path to program config scaner</source>
        <translation>Програма конфіг. scaner</translation>
    </message>
    <message>
        <source>Path to program config mount devices</source>
        <translation>Програма конфіг.mount devices</translation>
    </message>
    <message>
        <source>Path to program info Hardware</source>
        <translation>Програма конфіг.Hardware</translation>
    </message>
    <message>
        <source>Path to program config soundcart</source>
        <translation>Програма конфіг.soundcart</translation>
    </message>
    <message>
        <source>Path to program config keyboard</source>
        <translation>Програма конфіг.keyboard</translation>
    </message>
    <message>
        <source>Path to program config printer</source>
        <translation>Програма конфіг.printer</translation>
    </message>
    <message>
        <source>Path to program config mouse</source>
        <translation>Програма конфіг.mouse</translation>
    </message>
    <message>
        <source>Path to program boot config</source>
        <translation>Програма конфіг.boot config</translation>
    </message>
    <message>
        <source>Networ&amp;k, Packages</source>
        <translation type="unfinished">Мережа, Пакунки</translation>
    </message>
    <message>
        <source>Path to program config Packages</source>
        <translation>Програма конфіг.Packages</translation>
    </message>
    <message>
        <source>Path to program config network</source>
        <translation>Програма конфіг.network</translation>
    </message>
    <message>
        <source>Path to program config Samba</source>
        <translation>Програма конфіг.Samba</translation>
    </message>
    <message>
        <source>Path to program config DHCP</source>
        <translation>Програма конфіг.DHCP</translation>
    </message>
    <message>
        <source>Path to program config Web Server</source>
        <translation>Програма конфіг.Web Server</translation>
    </message>
    <message>
        <source>Path to program config NFS</source>
        <translation>Програма конфіг.NFS</translation>
    </message>
    <message>
        <source>Path to program config FTP</source>
        <translation>Програма конфіг.FTP</translation>
    </message>
    <message>
        <source>Path to program config Mail</source>
        <translation>Програма конфіг.Mail</translation>
    </message>
    <message>
        <source>Path to program config DNS</source>
        <translation>Програма конфіг.DNS</translation>
    </message>
    <message>
        <source>Path to program config Proxy</source>
        <translation>Програма конфіг.Proxy</translation>
    </message>
    <message>
        <source>System</source>
        <translation>Система</translation>
    </message>
    <message>
        <source>Path to program config Date</source>
        <translation>Програма конфіг.Date</translation>
    </message>
    <message>
        <source>Path to program config Users</source>
        <translation>Програма конфіг. Users</translation>
    </message>
    <message>
        <source>Path to program config Security</source>
        <translation>Програма конфіг.Security</translation>
    </message>
    <message>
        <source>Path to program config Root password</source>
        <translation>Програма конфіг.Root password</translation>
    </message>
    <message>
        <source>Path to program config Services</source>
        <translation>Програма конфіг.Services</translation>
    </message>
    <message>
        <source>Path to program view Syslog</source>
        <translation>Програма конфіг.Syslog</translation>
    </message>
    <message>
        <source>Path to program config Laguange</source>
        <translation>Програма конфіг.Laguange</translation>
    </message>
    <message>
        <source>Other</source>
        <translation>Інше</translation>
    </message>
    <message>
        <source>Add icon program in menu (current user only)</source>
        <translation>Додати іконку програми в меню (тільки для поточного користувача)</translation>
    </message>
    <message>
        <source>Add icon program in desktop (current user only)</source>
        <translation>Додати іконку на робочий стіл (тільки для поточного користувача)</translation>
    </message>
    <message>
        <source>Language</source>
        <translation>Мова</translation>
    </message>
</context>
<context>
    <name>myConfDlg</name>
    <message>
        <source>&amp;File</source>
        <translation type="obsolete">&amp;Файл</translation>
    </message>
    <message>
        <source>&amp;Help</source>
        <translation type="obsolete">&amp;Довідка</translation>
    </message>
    <message>
        <source>Exit</source>
        <translation type="obsolete">Вихід</translation>
    </message>
    <message>
        <source>E&amp;xit</source>
        <translation type="obsolete">Вихід</translation>
    </message>
    <message>
        <source>Index</source>
        <translation type="obsolete">Індекс</translation>
    </message>
    <message>
        <source>&amp;Index...</source>
        <translation type="obsolete">Індекс</translation>
    </message>
    <message>
        <source>About</source>
        <translation type="obsolete">Про</translation>
    </message>
    <message>
        <source>&amp;About</source>
        <translation type="obsolete">Про</translation>
    </message>
    <message>
        <source>Preferences</source>
        <translation type="obsolete">Налаштування</translation>
    </message>
    <message>
        <source>Show dialog Preferences</source>
        <translation type="obsolete">Показати діалог налаштування</translation>
    </message>
    <message>
        <source>Clasik</source>
        <translation type="obsolete">Класичний</translation>
    </message>
    <message>
        <source>Clasik view left panel</source>
        <translation type="obsolete">Класичний вигляд лівої панелі</translation>
    </message>
    <message>
        <source>New</source>
        <translation type="obsolete">Новий</translation>
    </message>
    <message>
        <source>New view left panel</source>
        <translation type="obsolete">Новітній вигляд лівої панелі</translation>
    </message>
</context>
<context>
    <name>myConfImpl</name>
    <message>
        <source>Any files (*.*)</source>
        <translation>Будь-який файл (*.*)</translation>
    </message>
    <message>
        <source>Select Execute file</source>
        <translation>Веберіть виконуваний файл</translation>
    </message>
    <message>
        <source>Information</source>
        <translation>Інформація</translation>
    </message>
    <message>
        <source>Change laguange after restart program</source>
        <translation>Мова зміниться після перезавантаження програми</translation>
    </message>
</context>
<context>
    <name>myConfigImpl</name>
    <message>
        <source>Standart View</source>
        <translation type="obsolete">Стандартний вигляд</translation>
    </message>
    <message>
        <source>&amp;Standart View</source>
        <translation type="obsolete">Стандартний вигляд</translation>
    </message>
    <message>
        <source>Button View</source>
        <translation type="obsolete">Кнопковий вигляд</translation>
    </message>
    <message>
        <source>&amp;Button View</source>
        <translation type="obsolete">Кнопковий вигляд</translation>
    </message>
    <message>
        <source>Detailed View</source>
        <translation type="obsolete">Детальний вигляд</translation>
    </message>
    <message>
        <source>&amp;Detailed View</source>
        <translation type="obsolete">Детальний вигляд</translation>
    </message>
    <message>
        <source>Short View</source>
        <translation type="obsolete">Короткий вигляд</translation>
    </message>
    <message>
        <source>&amp;Short View</source>
        <translation type="obsolete">Короткий вигляд</translation>
    </message>
    <message>
        <source>&amp;View</source>
        <translation type="obsolete">Вигляд</translation>
    </message>
    <message>
        <source>Left panel</source>
        <translation type="obsolete">Ліва панель</translation>
    </message>
    <message>
        <source>Right panel</source>
        <translation type="obsolete">Права панель</translation>
    </message>
    <message>
        <source>Ready</source>
        <translation type="obsolete">Готово</translation>
    </message>
    <message>
        <source>Info</source>
        <translation type="obsolete">Інфо.</translation>
    </message>
    <message>
        <source>Can&apos;t find help files</source>
        <translation type="obsolete">Не можу знайти файли допомоги</translation>
    </message>
    <message>
        <source>English: Press the icon in left panel and select tool in righs panel.
</source>
        <translation type="obsolete">Натисніть на іконку у лівій панелі і веберіть засіб у правій</translation>
    </message>
    <message>
        <source>

En: Made in Ukraine.
</source>
        <translation type="obsolete">(new line)
 Зроблено в Україні</translation>
    </message>
    <message>
        <source>Information</source>
        <translation type="obsolete">Інформація</translation>
    </message>
    <message>
        <source>Press the icon in left panel and select tool in righs panel.
</source>
        <translation type="obsolete">Натисніть на піктонраму в лівійпанелі та виберіть програму у правій\n</translation>
    </message>
    <message>
        <source>Made in Ukraine.
</source>
        <translation type="obsolete">Зроблено в Україні</translation>
    </message>
    <message>
        <source>Press the icon in left panel and select tool in righs panel.</source>
        <translation type="obsolete">Натисніть на піктограму в лівій панелі та виберіть програму у правій панелі</translation>
    </message>
    <message>
        <source>Press the icon in left panel
 and select tool in righs panel.</source>
        <translation type="obsolete">Натисніть на піктограму в лівій панелі
та виберіть програму у правій панелі.</translation>
    </message>
    <message>
        <source>Please wait. Program is loading ...</source>
        <translation type="obsolete">Будь-ласка зачекайте. Завантажується програма ...</translation>
    </message>
    <message>
        <source>Press the icon in left panel
 and select tool in righs panel.

Developers and Designers:
Peter Komar (peter_komar@mail.ru)
Kurt Santes (pkdev@mail.ru)</source>
        <translation type="obsolete">Натисніть на піктограму в лівій панелі
і виберіть програму в правій.

Розробники і дизайнери:
Peter Komar (peter_komar@mail.ru)
Kurt Santes (pkdev@mail.ru)</translation>
    </message>
</context>
<context>
    <name>myQLoader</name>
    <message>
        <source>(Configure your boot loader)</source>
        <translation type="obsolete">Налаштовує ваш завантажувач</translation>
    </message>
    <message>
        <source>boot</source>
        <translation></translation>
    </message>
    <message>
        <source>Boot config</source>
        <translation>Завантажувачі</translation>
    </message>
    <message>
        <source>(Listen information of your computer)</source>
        <translation type="obsolete">Показує інформацію про ваш комп&apos;ютер</translation>
    </message>
    <message>
        <source>Hardware</source>
        <translation>Залізо</translation>
    </message>
    <message>
        <source>Devices</source>
        <translation>Пристрої</translation>
    </message>
    <message>
        <source>(Configure your display)</source>
        <translation type="obsolete">Налаштовує ваш дисплей</translation>
    </message>
    <message>
        <source>Display</source>
        <translation>Екран</translation>
    </message>
    <message>
        <source>(Configure your sound cart)</source>
        <translation type="obsolete">Налаштовує вашу звукову картку</translation>
    </message>
    <message>
        <source>Soundcart</source>
        <translation>Звукова карта</translation>
    </message>
    <message>
        <source>(Configure your keyboard)</source>
        <translation type="obsolete">Налаштовує вашу клавіатуру</translation>
    </message>
    <message>
        <source>Keyboard</source>
        <translation>Клавіатура</translation>
    </message>
    <message>
        <source>(Configure your printer)</source>
        <translation type="obsolete">Налаштовує ваш принтер</translation>
    </message>
    <message>
        <source>Printer</source>
        <translation>Принтер</translation>
    </message>
    <message>
        <source>(Configure your scaner)</source>
        <translation type="obsolete">Налаштовує ваш сканер</translation>
    </message>
    <message>
        <source>Scaner</source>
        <translation>Сканер</translation>
    </message>
    <message>
        <source>(Configure your mouse)</source>
        <translation type="obsolete">Налаштовує вашу мишку</translation>
    </message>
    <message>
        <source>Mouse</source>
        <translation>Миша</translation>
    </message>
    <message>
        <source>(Your mount manager)</source>
        <translation type="obsolete">Ваш менеджер монтування</translation>
    </message>
    <message>
        <source>Mount Points</source>
        <translation>Розділи</translation>
    </message>
    <message>
        <source>Hard Disk</source>
        <translation>Жорсткий диск</translation>
    </message>
    <message>
        <source>(Configure your network)</source>
        <translation type="obsolete">Налаштовує вашу мережу</translation>
    </message>
    <message>
        <source>Network</source>
        <translation>Мережа</translation>
    </message>
    <message>
        <source>(Configure Web server)</source>
        <translation type="obsolete">Налаштовує ваш Web серевер</translation>
    </message>
    <message>
        <source>Web Server</source>
        <translation>Веб сервер</translation>
    </message>
    <message>
        <source>(Configure Samba server)</source>
        <translation type="obsolete">Налаштовує ваш Самба серевер</translation>
    </message>
    <message>
        <source>Samba</source>
        <translation>Самба сервер</translation>
    </message>
    <message>
        <source>(Configure NFS server)</source>
        <translation type="obsolete">Налаштовує ваш NFS серевер</translation>
    </message>
    <message>
        <source>NFS</source>
        <translation>NFS сервер</translation>
    </message>
    <message>
        <source>(Configure FTP server)</source>
        <translation type="obsolete">Налаштовує FTP серевер</translation>
    </message>
    <message>
        <source>FTP</source>
        <translation>FTP сервер</translation>
    </message>
    <message>
        <source>(Configure Mail Server)</source>
        <translation type="obsolete">Налаштовує вашу пошту</translation>
    </message>
    <message>
        <source>Mail</source>
        <translation>Пошта</translation>
    </message>
    <message>
        <source>(Configure DNS Server)</source>
        <translation type="obsolete">Налаштовує ваш DNS сервер</translation>
    </message>
    <message>
        <source>DNS</source>
        <translation>DNS сервер</translation>
    </message>
    <message>
        <source>(Configure DHCP Server)</source>
        <translation type="obsolete">Налаштовує ваш DHCP сервер</translation>
    </message>
    <message>
        <source>DHCP</source>
        <translation>DHCP сервер</translation>
    </message>
    <message>
        <source>(Configure Proxy Server)</source>
        <translation type="obsolete">Налаштовує ваш проксі серевер</translation>
    </message>
    <message>
        <source>Proxy</source>
        <translation>Проксі сервер</translation>
    </message>
    <message>
        <source>(Your package manager)</source>
        <translation type="obsolete">Ваш менеджер пакунків</translation>
    </message>
    <message>
        <source>Packages</source>
        <translation>Пакунки</translation>
    </message>
    <message>
        <source>Software</source>
        <translation>Пакунки</translation>
    </message>
    <message>
        <source>(Configure users or groups in your computer)</source>
        <translation type="obsolete">Конфігурує користувачів та групи на вашому комп&apos;ютері</translation>
    </message>
    <message>
        <source>Users and Groups</source>
        <translation>Користувачі та групи</translation>
    </message>
    <message>
        <source>System</source>
        <translation>Система</translation>
    </message>
    <message>
        <source>(Configure date and time)</source>
        <translation type="obsolete">Налаштовує дату і час</translation>
    </message>
    <message>
        <source>Date and Time</source>
        <translation>Дата і час</translation>
    </message>
    <message>
        <source>(Listen System Log files)</source>
        <translation type="obsolete">Перегляд файлів журналу</translation>
    </message>
    <message>
        <source>Sys Log</source>
        <translation>Системний журнал</translation>
    </message>
    <message>
        <source>(Configure Services in your Computer)</source>
        <translation type="obsolete">Конфігурує сервіси на вашому комп&apos;ютері </translation>
    </message>
    <message>
        <source>Services</source>
        <translation>Сервіси</translation>
    </message>
    <message>
        <source>(Change root password)</source>
        <translation type="obsolete">Міняє пароль користувача root</translation>
    </message>
    <message>
        <source>Root Password</source>
        <translation>Пароль root</translation>
    </message>
    <message>
        <source>(Configure Security in your Computer)</source>
        <translation type="obsolete">Налаштовує безпеку на вашому комп&apos;ютері</translation>
    </message>
    <message>
        <source>Security</source>
        <translation>Безпека</translation>
    </message>
    <message>
        <source>Language</source>
        <translation>Мова системи</translation>
    </message>
    <message>
        <source>(Add packages)</source>
        <translation>(Додавання пакунків)</translation>
    </message>
    <message>
        <source>Add rpm</source>
        <translation>Додати пакунки</translation>
    </message>
    <message>
        <source>(Remove packages)</source>
        <translation>(Видаляння пакунків)</translation>
    </message>
    <message>
        <source>Remove rpm</source>
        <translation>Видалити пакунки</translation>
    </message>
    <message>
        <source>Configure your boot loader</source>
        <translation>Налаштовує ваш завантажувач</translation>
    </message>
    <message>
        <source>Listen information of your computer</source>
        <translation>Читає інформацію про ваш комп&apos;ютер</translation>
    </message>
    <message>
        <source>Configure your display</source>
        <translation>Налаштовує ваш дисплей</translation>
    </message>
    <message>
        <source>Configure your sound cart</source>
        <translation>Налаштовує вашу звукову карту</translation>
    </message>
    <message>
        <source>Configure your keyboard</source>
        <translation>Налаштовує вашу клавіатуру</translation>
    </message>
    <message>
        <source>Configure your printer</source>
        <translation>Налаштовує ваш принтер</translation>
    </message>
    <message>
        <source>Configure your scaner</source>
        <translation>Налаштовує ваш сканер</translation>
    </message>
    <message>
        <source>Configure your mouse</source>
        <translation>Налаштовує вашу мишу</translation>
    </message>
    <message>
        <source>Your mount manager</source>
        <translation>Ваш менеджер монтування</translation>
    </message>
    <message>
        <source>Configure your network</source>
        <translation>Налаштовує вашу мережу</translation>
    </message>
    <message>
        <source>Configure Web server</source>
        <translation>Налаштовує ваш веб сервер</translation>
    </message>
    <message>
        <source>Configure Samba server</source>
        <translation>Налаштовує вашу Самбу</translation>
    </message>
    <message>
        <source>Configure NFS server</source>
        <translation>Налаштовує NFS серевер</translation>
    </message>
    <message>
        <source>Configure FTP server</source>
        <translation>Налаштовує FTP сервер</translation>
    </message>
    <message>
        <source>Configure mail in your computer</source>
        <translation>Налаштовує пошту на вашому комп&apos;ютері</translation>
    </message>
    <message>
        <source>Configure DNS Server</source>
        <translation>Налаштовує DNS сервер</translation>
    </message>
    <message>
        <source>Configure DHCP Server</source>
        <translation>Налаштовує DHCP сервер</translation>
    </message>
    <message>
        <source>Configure Proxy</source>
        <translation>Налаштовує проксі</translation>
    </message>
    <message>
        <source>Your package manager</source>
        <translation>Ваш менеджер пакунків</translation>
    </message>
    <message>
        <source>Configure users or groups in your computer</source>
        <translation>Налаштування користувачів та груп на вашому комп&apos;ютері</translation>
    </message>
    <message>
        <source>Configure date and time</source>
        <translation>Налаштування дати та часу</translation>
    </message>
    <message>
        <source>Listen System Log files</source>
        <translation>Читання системного журналу</translation>
    </message>
    <message>
        <source>Configure Services in your Computer</source>
        <translation>Налаштування сервісів</translation>
    </message>
    <message>
        <source>Change root password</source>
        <translation>Зміна паролю суперкористувача root</translation>
    </message>
    <message>
        <source>Configure Security in your Computer</source>
        <translation>Налаштування безпеки на вашому комп&apos;ютері</translation>
    </message>
    <message>
        <source>Select languange in your computer</source>
        <translation>Вибір мови на вашому комп&apos;ютері</translation>
    </message>
</context>
<context>
    <name>myconfcenter</name>
    <message>
        <source>Ready</source>
        <translation>Готово</translation>
    </message>
    <message>
        <source>myConfig use QT</source>
        <translation type="obsolete">myConfig використовує Qt</translation>
    </message>
    <message>
        <source>View</source>
        <translation>Вигляд</translation>
    </message>
    <message>
        <source>Help</source>
        <translation>Довідка</translation>
    </message>
    <message>
        <source>Preferencess</source>
        <translation>Налаштування</translation>
    </message>
    <message>
        <source>Exit</source>
        <translation>Вихід</translation>
    </message>
    <message>
        <source>Detailed View</source>
        <translation>Детальний вигляд</translation>
    </message>
    <message>
        <source>&amp;Detailed View</source>
        <translation type="unfinished">Детальний вигляд</translation>
    </message>
    <message>
        <source>About</source>
        <translation>Про</translation>
    </message>
    <message>
        <source>Please wait. %1 is loading ...</source>
        <translation>Будь-ласка зачекайте. Завантажується %1 ...</translation>
    </message>
    <message>
        <source>Info</source>
        <translation>Інфо</translation>
    </message>
    <message>
        <source>Can&apos;t find help files</source>
        <translation type="obsolete">Не можу знайти файли довідки</translation>
    </message>
    <message>
        <source>Lilo</source>
        <translation type="obsolete">Ліло</translation>
    </message>
    <message>
        <source>File</source>
        <translation>Файл</translation>
    </message>
    <message>
        <source>SCT use QT</source>
        <translation>SCT використовує Qt</translation>
    </message>
    <message>
        <source>Can&apos;t find help system.</source>
        <translation>Не можу знайти довідку.</translation>
    </message>
    <message>
        <source>Information</source>
        <translation>Інформація</translation>
    </message>
    <message>
        <source>You execute control center not like root.
Somes programs and modules maybe not correct run.</source>
        <translation>Ви запустили центр керування не як root.
Деякі програми та модулі можуть неправильно працювати.</translation>
    </message>
    <message>
        <source>About: %1 </source>
        <translation></translation>
    </message>
</context>
<context>
    <name>myconfviews</name>
    <message>
        <source>Error Load</source>
        <translation>Помилка завантаження</translation>
    </message>
    <message>
        <source>Can&apos;t load icon</source>
        <translation>Неможливо завантажити іконки </translation>
    </message>
    <message>
        <source>Boot config</source>
        <translation>Завантажувачі</translation>
    </message>
    <message>
        <source>Hard Disk</source>
        <translation>Жорсткий диск</translation>
    </message>
    <message>
        <source>Devices</source>
        <translation>Пристрої</translation>
    </message>
    <message>
        <source>Network</source>
        <translation>Мережа</translation>
    </message>
    <message>
        <source>Software</source>
        <translation>Пакунки</translation>
    </message>
    <message>
        <source>System</source>
        <translation>Система</translation>
    </message>
    <message>
        <source>Configure Tools</source>
        <translation>Засіб завантаження</translation>
    </message>
    <message>
        <source>Information</source>
        <translation>Інформація</translation>
    </message>
    <message>
        <source>Linux name:</source>
        <translation type="obsolete">Назва Лінукса:</translation>
    </message>
    <message>
        <source>&lt;font color=&quot;#5555ff&quot; size=&quot;-1&quot; face=&quot;Arial&quot;&gt;Computer name :&lt;/font&gt; %1&lt;br&gt;&lt;br&gt;</source>
        <translation type="obsolete">&lt;font color=&quot;#5555ff&quot; size=&quot;-1&quot; face=&quot;Arial&quot;&gt;Ім&apos;я комп&apos;ютера :&lt;/font&gt; %1&lt;br&gt;&lt;br&gt;</translation>
    </message>
    <message>
        <source>&lt;font color=&quot;#5555ff&quot; size=&quot;-1&quot; face=&quot;Arial&quot;&gt;Kernel architecture :&lt;/font&gt; %1&lt;br&gt;</source>
        <translation type="obsolete">&lt;font color=&quot;#5555ff&quot; size=&quot;-1&quot; face=&quot;Arial&quot;&gt;Архітектура ядра :&lt;/font&gt; %1&lt;br&gt;</translation>
    </message>
    <message>
        <source>&lt;font color=&quot;#5555ff&quot; size=&quot;-1&quot; face=&quot;Arial&quot;&gt;Kernel release :&lt;/font&gt; %1&lt;br&gt;</source>
        <translation type="obsolete">&lt;font color=&quot;#5555ff&quot; size=&quot;-1&quot; face=&quot;Arial&quot;&gt;Реліз ядра :&lt;/font&gt; %1&lt;br&gt;</translation>
    </message>
    <message>
        <source>&lt;font color=&quot;#5555ff&quot; size=&quot;-1&quot; face=&quot;Arial&quot;&gt;Kernel version : &lt;/font&gt;%1&lt;br&gt;&lt;br&gt;</source>
        <translation type="obsolete">&lt;font color=&quot;#5555ff&quot; size=&quot;-1&quot; face=&quot;Arial&quot;&gt;Версія ядра : &lt;/font&gt;%1&lt;br&gt;&lt;br&gt;</translation>
    </message>
    <message>
        <source>&lt;font color=&quot;#5555ff&quot; size=&quot;-1&quot; face=&quot;Arial&quot;&gt;Total RAM :&lt;/font&gt; %1 MB</source>
        <translation type="obsolete">&lt;font color=&quot;#5555ff&quot; size=&quot;-1&quot; face=&quot;Arial&quot;&gt;Пам&apos;ять :&lt;/font&gt; %1 MB</translation>
    </message>
    <message>
        <source>&lt;font color=&quot;#5555ff&quot; size=&quot;2&quot; face=&quot;Arial&quot;&gt;&lt;p align=&quot;center&quot;&gt;System information:&lt;/p&gt;</source>
        <translation type="obsolete">&lt;font color=&quot;#5555ff&quot; size=&quot;2&quot; face=&quot;Arial&quot;&gt;&lt;p align=&quot;center&quot;&gt;Iнформація про систему:&lt;/p&gt;</translation>
    </message>
    <message>
        <source>CPU Name : %1&lt;br&gt;</source>
        <translation type="obsolete">Імя CPU : %1&lt;br&gt;</translation>
    </message>
    <message>
        <source>Cache size : %1&lt;br&gt;</source>
        <translation type="obsolete">Розмір кешу : %1&lt;br&gt;</translation>
    </message>
    <message>
        <source>Computer name : %1&lt;br&gt;</source>
        <translation type="obsolete">Ім&apos;я комп&apos;ютера : %1&lt;br&gt;</translation>
    </message>
    <message>
        <source>Kernel architecture : %1&lt;br&gt;</source>
        <translation type="obsolete">Архітектура ядра : %1&lt;br&gt;</translation>
    </message>
    <message>
        <source>Kernel version : %1&lt;br&gt;</source>
        <translation type="obsolete">Версія ядра : %1&lt;br&gt;</translation>
    </message>
    <message>
        <source>Memory : %1 MB&lt;/font&gt;</source>
        <translation type="obsolete">Пам&apos;ять : %1 MB&lt;/font&gt;</translation>
    </message>
    <message>
        <source>Tools</source>
        <translation>Інструменти</translation>
    </message>
    <message>
        <source>System information</source>
        <translation>Інформація про систему</translation>
    </message>
</context>
</TS>
